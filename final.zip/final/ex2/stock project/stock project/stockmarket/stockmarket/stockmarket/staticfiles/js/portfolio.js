document.addEventListener('DOMContentLoaded', function() {
    initializePortfolio();
    setupCharts();
    setupEventListeners();
    startLiveUpdates();
    initializeBenchmarkChart();
    initializePortfolioChart();

    const modal = document.getElementById('addStockModal');
    const addStockBtn = document.querySelector('#addStockBtn');
    const closeBtn = document.querySelector('.close');
    const addStockForm = document.getElementById('addStockForm');

    // Prevent default link behavior and show modal
    addStockBtn.addEventListener('click', function(e) {
        e.preventDefault();
        modal.style.display = "block";
    });

    // Close modal
    closeBtn.addEventListener('click', function() {
        modal.style.display = "none";
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    });

    // Handle form submission
    addStockForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = new FormData();
        formData.append('symbol', document.getElementById('stockSymbol').value.toUpperCase());
        formData.append('quantity', document.getElementById('quantity').value);
        formData.append('purchase_price', document.getElementById('purchasePrice').value);
        formData.append('purchase_date', document.getElementById('purchaseDate').value);
        formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);

        try {
            const response = await fetch('/stock/add_stock/', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                modal.style.display = "none";
                addStockForm.reset();
                window.location.reload(); // Reload the page to show updated holdings
            } else {
                const data = await response.json();
                alert('Error adding stock: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error adding stock. Please try again.');
        }
    });

    const editModal = document.getElementById('editModal');
    const editForm = document.getElementById('editStockForm');
    const closeBtnEdit = editModal.querySelector('.close');

    // Edit button click handlers
    document.querySelectorAll('.btn-edit').forEach(button => {
        button.addEventListener('click', function() {
            const stockData = this.dataset;
            document.getElementById('editStockId').value = stockData.stockId;
            document.getElementById('editSymbol').value = stockData.symbol;
            document.getElementById('editQuantity').value = stockData.quantity;
            document.getElementById('editPrice').value = stockData.price;
            document.getElementById('editDate').value = stockData.date;
            editModal.style.display = 'block';
        });
    });

    // Close modal
    closeBtnEdit.addEventListener('click', () => editModal.style.display = 'none');
    window.addEventListener('click', (e) => {
        if (e.target === editModal) editModal.style.display = 'none';
    });

    // Edit form submission
    editForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const stockId = document.getElementById('editStockId').value;
        const formData = new FormData();
        formData.append('quantity', document.getElementById('editQuantity').value);
        formData.append('purchase_price', document.getElementById('editPrice').value);
        formData.append('purchase_date', document.getElementById('editDate').value);
        formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);

        try {
            const response = await fetch(`/stock/edit_stock/${stockId}/`, {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                window.location.reload();
            } else {
                const data = await response.json();
                alert(data.error || 'Error updating stock');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error updating stock');
        }
    });

    // Delete button click handlers
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', async function() {
            if (confirm('Are you sure you want to delete this stock?')) {
                const stockId = this.dataset.stockId;
                try {
                    const response = await fetch(`/stock/delete_stock/${stockId}/`, {
                        method: 'POST',
                        headers: {
                            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                        }
                    });

                    if (response.ok) {
                        window.location.reload();
                    } else {
                        alert('Error deleting stock');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error deleting stock');
                }
            }
        });
    });
});

// Initialize Portfolio Data
function initializePortfolio() {
    const mockHoldings = [
        {
            symbol: 'RELIANCE',
            quantity: 100,
            avgCost: 2450.75,
            ltp: 2890.30,
            currentValue: 289030,
            pnl: 43955,
            returns: 17.93
        },
        {
            symbol: 'TCS',
            quantity: 50,
            avgCost: 3450.00,
            ltp: 3890.60,
            currentValue: 194530,
            pnl: 22030,
            returns: 12.75
        },
        {
            symbol: 'INFY',
            quantity: 75,
            avgCost: 1580.25,
            ltp: 1690.80,
            currentValue: 126810,
            pnl: 8291,
            returns: 6.99
        }
    ];

    updateHoldingsTable(mockHoldings);
}

// Setup Charts
function setupCharts() {
    // Portfolio Performance Chart
    const performanceCtx = document.getElementById('portfolioChart').getContext('2d');
    new Chart(performanceCtx, {
        type: 'line',
        data: {
            labels: generateDateLabels(30),
            datasets: [{
                label: 'Portfolio Value',
                data: generatePerformanceData(30),
                borderColor: '#4a90e2',
                backgroundColor: 'rgba(74, 144, 226, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Sector Distribution Chart
    const sectorCtx = document.getElementById('sectorChart').getContext('2d');
    new Chart(sectorCtx, {
        type: 'doughnut',
        data: {
            labels: ['IT', 'Banking', 'Pharma', 'Auto', 'FMCG'],
            datasets: [{
                data: [30, 25, 15, 20, 10],
                backgroundColor: [
                    '#4a90e2',
                    '#67b26f',
                    '#f953c6',
                    '#f9d423',
                    '#8e44ad'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Event Listeners
function setupEventListeners() {
    // Time Filter Buttons
    document.querySelectorAll('.time-filter').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelector('.time-filter.active').classList.remove('active');
            this.classList.add('active');
            updateChartData(this.textContent);
        });
    });

    // Add Stock Modal
    const modal = document.getElementById('addStockModal');
    const addStockBtn = document.getElementById('addStockBtn');
    const closeBtn = document.querySelector('.close');

    addStockBtn.onclick = () => modal.style.display = 'block';
    closeBtn.onclick = () => modal.style.display = 'none';
    window.onclick = (e) => {
        if (e.target == modal) modal.style.display = 'none';
    };

    // Add Stock Form
    document.getElementById('addStockForm').onsubmit = function(e) {
        e.preventDefault();
        const formData = {
            symbol: document.getElementById('stockSymbol').value,
            quantity: document.getElementById('quantity').value,
            purchasePrice: document.getElementById('purchasePrice').value,
            purchaseDate: document.getElementById('purchaseDate').value
        };
        addNewStock(formData);
        modal.style.display = 'none';
        this.reset();
    };

    // Holdings Table Sorting
    document.querySelectorAll('.holdings-table th').forEach(header => {
        header.addEventListener('click', () => {
            const column = header.textContent.trim();
            sortHoldings(column);
        });
    });
}

// Helper Functions
function generateDateLabels(days) {
    const labels = [];
    const today = new Date();
    for (let i = days; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
    return labels;
}

function generatePerformanceData(days) {
    const data = [];
    let value = 1500000;
    for (let i = 0; i <= days; i++) {
        value *= (1 + (Math.random() * 0.02 - 0.01));
        data.push(value);
    }
    return data;
}

function updateHoldingsTable(holdings) {
    const tableBody = document.getElementById('holdingsTableBody');
    tableBody.innerHTML = holdings.map(stock => `
        <tr>
            <td>${stock.symbol}</td>
            <td>${stock.quantity}</td>
            <td>₹${stock.purchase_price.toFixed(2)}</td>
            <td>₹${stock.ltp.toFixed(2)}</td>
            <td>₹${stock.current_value.toLocaleString()}</td>
            <td class="${stock.pnl >= 0 ? 'profit' : 'loss'}">
                ₹${Math.abs(stock.pnl).toLocaleString()}
            </td>
            <td class="${stock.net_returns >= 0 ? 'profit' : 'loss'}">
                ${stock.net_returns.toFixed(2)}%
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn-edit" data-id="${stock.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" data-id="${stock.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    // Add event listeners after updating table
    addButtonEventListeners();
}

function addButtonEventListeners() {
    // Edit button listeners
    document.querySelectorAll('.btn-edit').forEach(button => {
        button.addEventListener('click', async () => {
            const stockId = button.dataset.id;
            try {
                const response = await fetch(`/stock/get_stock/${stockId}/`);
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('editStockId').value = stockId;
                    document.getElementById('editSymbol').value = data.stock.symbol;
                    document.getElementById('editQuantity').value = data.stock.quantity;
                    document.getElementById('editPrice').value = data.stock.purchase_price;
                    document.getElementById('editDate').value = data.stock.purchase_date;
                    
                    document.getElementById('editModal').style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Error loading stock data');
            }
        });
    });

    // Delete button listeners
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', async () => {
            if (confirm('Are you sure you want to delete this stock?')) {
                const stockId = button.dataset.id;
                try {
                    const response = await fetch(`/stock/delete_stock/${stockId}/`, {
                        method: 'POST',
                        headers: {
                            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                        }
                    });

                    if (response.ok) {
                        window.location.reload();
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error deleting stock');
                }
            }
        });
    });
}

// Live Updates
function startLiveUpdates() {
    setInterval(() => {
        updateStockPrices();
        updatePortfolioMetrics();
    }, 5000);
}

function updateStockPrices() {
    // Simulate live price updates
    const holdings = document.querySelectorAll('.holdings-table tbody tr');
    holdings.forEach(row => {
        const ltpCell = row.cells[3];
        const currentPrice = parseFloat(ltpCell.textContent.replace('₹', ''));
        const newPrice = currentPrice * (1 + (Math.random() * 0.02 - 0.01));
        ltpCell.textContent = `₹${newPrice.toFixed(2)}`;
        updateRowCalculations(row, newPrice);
    });
}

function updateRowCalculations(row, newPrice) {
    const quantity = parseInt(row.cells[1].textContent);
    const avgCost = parseFloat(row.cells[2].textContent.replace('₹', ''));
    
    const currentValue = quantity * newPrice;
    const pnl = currentValue - (quantity * avgCost);
    const returns = (pnl / (quantity * avgCost)) * 100;

    row.cells[4].textContent = `₹${currentValue.toLocaleString()}`;
    row.cells[5].textContent = `₹${Math.abs(pnl).toLocaleString()}`;
    row.cells[5].className = pnl >= 0 ? 'up' : 'down';
    row.cells[6].textContent = `${returns.toFixed(2)}%`;
    row.cells[6].className = returns >= 0 ? 'up' : 'down';
}

function initializeBenchmarkChart() {
    const ctx = document.getElementById('benchmarkChart');
    
    if (!ctx) {
        console.error('Benchmark chart canvas not found');
        return;
    }

    try {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [
                    {
                        label: 'Portfolio',
                        data: [65, 67, 70, 68, 72, 75, 73, 78, 80, 82, 85, 88],
                        borderColor: '#4a90e2',
                        tension: 0.4,
                        fill: false
                    },
                    {
                        label: 'NIFTY 50',
                        data: [60, 62, 65, 63, 68, 70, 69, 73, 75, 76, 78, 80],
                        borderColor: '#22c55e',
                        tension: 0.4,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#8a8aa0',
                            font: {
                                size: 12
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#8a8aa0',
                            font: {
                                size: 11
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#8a8aa0',
                            font: {
                                size: 11
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error initializing benchmark chart:', error);
    }
}

function initializePortfolioChart() {
    const ctx = document.getElementById('portfolioChart');
    
    if (!ctx) {
        console.error('Portfolio chart canvas not found');
        return;
    }

    try {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Portfolio Value',
                    data: [100000, 105000, 103000, 106000, 108000, 115000, 112000, 118000, 122000, 125000, 128000, 130000],
                    borderColor: '#4a90e2',
                    backgroundColor: 'rgba(74, 144, 226, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#8a8aa0',
                            font: {
                                size: 11
                            },
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#8a8aa0',
                            font: {
                                size: 11
                            }
                        }
                    }
                }
            }
        });

        // Add click handlers for time filters
        document.querySelectorAll('.time-filter').forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                document.querySelectorAll('.time-filter').forEach(btn => 
                    btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                // TODO: Update chart data based on selected time period
            });
        });

    } catch (error) {
        console.error('Error initializing portfolio chart:', error);
    }
}

document.getElementById('addStockForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const stockData = {
        symbol: document.getElementById('stockSymbol').value,
        quantity: document.getElementById('quantity').value,
        purchase_price: document.getElementById('purchasePrice').value,
        purchase_date: document.getElementById('purchaseDate').value,
    };

    fetch('/add_stock/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        },
        body: JSON.stringify(stockData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close the modal and refresh the portfolio
            closeModal();
            loadPortfolio();
        } else {
            alert('Error adding stock');
        }
    });
});

function closeModal() {
    document.getElementById('addStockModal').style.display = 'none';
}

function loadPortfolio() {
    // Fetch and display the updated portfolio
    fetch('/portfolio_data/')
    .then(response => response.json())
    .then(data => {
        // Update the portfolio table with new data
        const holdingsTableBody = document.getElementById('holdingsTableBody');
        holdingsTableBody.innerHTML = '';
        data.holdings.forEach(stock => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${stock.symbol}</td>
                <td>${stock.quantity}</td>
                <td>${stock.purchase_price}</td>
                <td>${stock.ltp}</td>
                <td>${stock.current_value}</td>
                <td>${stock.pnl}</td>
                <td>${stock.net_returns}</td>
                <td><button class="btn-delete" data-id="${stock.id}">Delete</button></td>
            `;
            holdingsTableBody.appendChild(row);
        });
    });
}

// Get modal elements
const modal = document.getElementById('addStockModal');
const addStockBtn = document.getElementById('addStockBtn');
const closeBtn = document.querySelector('.close');
const addStockForm = document.getElementById('addStockForm');

// Show modal when Add Stock button is clicked
addStockBtn.addEventListener('click', () => {
    modal.style.display = 'block';
});

// Close modal when X is clicked
closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// Handle form submission
addStockForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('symbol', document.getElementById('stockSymbol').value.toUpperCase());
    formData.append('quantity', document.getElementById('quantity').value);
    formData.append('purchase_price', document.getElementById('purchasePrice').value);
    formData.append('purchase_date', document.getElementById('purchaseDate').value);
    formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);

    try {
        const response = await fetch('/stock/add_stock/', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            modal.style.display = 'none';
            addStockForm.reset();
            window.location.reload(); // Reload the page to show updated holdings
        } else {
            const data = await response.json();
            alert('Error adding stock: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error adding stock. Please try again.');
    }
});

// Function to delete stock
async function deleteStock(stockId) {
    if (confirm('Are you sure you want to delete this stock?')) {
        try {
            const response = await fetch(`/stock/delete_stock/${stockId}/`, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                }
            });

            if (response.ok) {
                window.location.reload();
            } else {
                alert('Error deleting stock');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error deleting stock');
        }
    }
}

// Add this to your existing script section in portfolio.html
async function editStock(stockId) {
    try {
        const response = await fetch(`/stock/get_stock/${stockId}/`);
        const data = await response.json();
        
        if (data.success) {
            // Populate the modal with existing stock data
            document.getElementById('stockSymbol').value = data.stock.symbol;
            document.getElementById('quantity').value = data.stock.quantity;
            document.getElementById('purchasePrice').value = data.stock.purchase_price;
            document.getElementById('purchaseDate').value = data.stock.purchase_date;
            
            // Show the modal
            const modal = document.getElementById('addStockModal');
            modal.style.display = "block";
            
            // Update form submission to handle edit
            const form = document.getElementById('addStockForm');
            form.dataset.mode = 'edit';
            form.dataset.stockId = stockId;
        } else {
            alert('Error loading stock data');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error loading stock data');
    }
}

// Edit button handler
document.addEventListener('click', function(e) {
    if (e.target.closest('.btn-edit')) {
        const button = e.target.closest('.btn-edit');
        const stockData = button.dataset;
        
        // Populate edit modal
        document.getElementById('editStockId').value = stockData.stockId;
        document.getElementById('editSymbol').value = stockData.symbol;
        document.getElementById('editQuantity').value = stockData.quantity;
        document.getElementById('editPrice').value = stockData.price;
        document.getElementById('editDate').value = stockData.date || new Date().toISOString().split('T')[0];
        
        // Show edit modal
        document.getElementById('editModal').style.display = 'block';
    }
});

// Delete button handler
document.addEventListener('click', function(e) {
    if (e.target.closest('.btn-delete')) {
        const button = e.target.closest('.btn-delete');
        const stockId = button.dataset.stockId;
        
        if (confirm('Are you sure you want to delete this stock?')) {
            deleteStock(stockId);
        }
    }
});

// Function to delete stock
async function deleteStock(stockId) {
    try {
        const response = await fetch(`/stock/delete_stock/${stockId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            }
        });

        if (response.ok) {
            window.location.reload();
        } else {
            const data = await response.json();
            alert('Error deleting stock: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error deleting stock');
    }
}

// Function to update stock
async function updateStock(e) {
    e.preventDefault();
    const stockId = document.getElementById('editStockId').value;
    
    const formData = new FormData();
    formData.append('quantity', document.getElementById('editQuantity').value);
    formData.append('purchase_price', document.getElementById('editPrice').value);
    formData.append('purchase_date', document.getElementById('editDate').value);
    formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);

    try {
        const response = await fetch(`/stock/edit_stock/${stockId}/`, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            document.getElementById('editModal').style.display = 'none';
            window.location.reload();
        } else {
            const data = await response.json();
            alert('Error updating stock: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating stock');
    }
}

// Add event listener for edit form submission
document.getElementById('editStockForm').addEventListener('submit', updateStock);

// Modal close handlers
document.querySelector('#editModal .close').addEventListener('click', function() {
    document.getElementById('editModal').style.display = 'none';
});

window.addEventListener('click', function(e) {
    const editModal = document.getElementById('editModal');
    if (e.target === editModal) {
        editModal.style.display = 'none';
    }
});

async function editStock(stockId) {
    try {
        const response = await fetch(`/stock/get_stock/${stockId}/`);
        const data = await response.json();
        
        if (data.success) {
            const editModal = document.getElementById('editModal');
            document.getElementById('editStockId').value = stockId;
            document.getElementById('editSymbol').value = data.stock.symbol;
            document.getElementById('editQuantity').value = data.stock.quantity;
            document.getElementById('editPrice').value = data.stock.purchase_price;
            document.getElementById('editDate').value = data.stock.purchase_date;
            
            editModal.style.display = 'block';
        } else {
            alert('Error loading stock data');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error loading stock data');
    }
}

async function deleteStock(stockId) {
    if (!confirm('Are you sure you want to delete this stock?')) {
        return;
    }

    try {
        const response = await fetch(`/stock/delete_stock/${stockId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            }
        });

        if (response.ok) {
            window.location.reload();
        } else {
            const data = await response.json();
            alert('Error deleting stock: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error deleting stock');
    }
}

// Edit form submission handler
document.getElementById('editStockForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const stockId = document.getElementById('editStockId').value;
    
    const formData = new FormData();
    formData.append('quantity', document.getElementById('editQuantity').value);
    formData.append('purchase_price', document.getElementById('editPrice').value);
    formData.append('purchase_date', document.getElementById('editDate').value);
    formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);

    try {
        const response = await fetch(`/stock/edit_stock/${stockId}/`, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            document.getElementById('editModal').style.display = 'none';
            window.location.reload();
        } else {
            const data = await response.json();
            alert('Error updating stock: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating stock');
    }
});

// Modal close handlers
document.querySelector('.close').addEventListener('click', () => {
    document.getElementById('editModal').style.display = 'none';
});

window.onclick = (event) => {
    const modal = document.getElementById('editModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
};
