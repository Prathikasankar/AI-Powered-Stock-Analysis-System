document.addEventListener('DOMContentLoaded', function() {
    // Add click handlers to company names
    document.querySelectorAll('.stock-table td:first-child').forEach(cell => {
        cell.style.cursor = 'pointer';
        cell.addEventListener('click', function() {
            const companyData = extractCompanyData(this.parentElement);
            showStockChart(companyData);
        });
    });
});

function extractCompanyData(row) {
    return {
        name: row.cells[0].textContent,      // Company Name
        symbol: row.cells[1].textContent,    // Symbol
        sector: row.cells[2].textContent,    // Sector
        industry: row.cells[3].textContent,  // Industry
        // Generate mock price and volume data since they're not in the table
        price: generateRandomPrice(),
        change: generateRandomChange(),
        volume: generateRandomVolume()
    };
}

// Helper functions to generate mock data
function generateRandomPrice() {
    return Math.random() * 1000 + 100; // Random price between 100 and 1100
}

function generateRandomChange() {
    return (Math.random() - 0.5) * 20; // Random change between -10 and +10
}

function generateRandomVolume() {
    return Math.floor(Math.random() * 1000000); // Random volume up to 1M
}

// Declare chart variables at a higher scope so they're accessible
let priceChart, volumeChart;
let currentMap; // Store the map instance globally

function showStockChart(data) {
    let popup = document.getElementById('stockChartPopup');
    if (!popup) {
        popup = createChartPopup();
    }

    // Update company information
    popup.querySelector('.company-name').textContent = `${data.name} (${data.symbol})`;
    popup.querySelector('.company-info').innerHTML = `
        <h2 class="company-name">${data.name} (${data.symbol})</h2>
        <div class="company-details">
            <span class="sector">${data.sector}</span> | 
            <span class="industry">${data.industry}</span>
        </div>
    `;

    // Show popup
    popup.style.display = 'flex';
    
    // Debug log
    console.log('Setting up chart with data:', data);

    // Clear any existing event listeners first
    const periodButtons = document.querySelectorAll('[data-period]');
    periodButtons.forEach(button => {
        button.replaceWith(button.cloneNode(true));
    });

    // Reselect buttons after replacing
    const newPeriodButtons = document.querySelectorAll('[data-period]');
    newPeriodButtons.forEach(button => {
        button.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('Period button clicked:', button.getAttribute('data-period'));

            // Visual feedback
            newPeriodButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const period = button.getAttribute('data-period');
            
            // For testing, let's use mock data first
            const mockData = generateMockDataForPeriod(period, data.symbol);
            updateChartsWithData(mockData);
        });
    });

    // Create initial charts with 1M data
    const initialData = generateMockDataForPeriod('1M', data.symbol);
    createOrUpdateCharts(initialData);
}

function generateMockDataForPeriod(period, symbol) {
    const points = {
        '1W': 7,
        '1M': 30,
        '3M': 90,
        '1Y': 365,
        'ALL': 730
    };

    const numDays = points[period] || 30;
    const today = new Date();
    const prices = [];
    const dates = [];
    const volumes = [];

    let basePrice = 100;
    for (let i = 0; i < numDays; i++) {
        const date = new Date(today);
        date.setDate(date.getDate() - (numDays - i));
        dates.push(date.toISOString().split('T')[0]);
        
        // Generate somewhat realistic looking price movements
        basePrice = basePrice + (Math.random() - 0.5) * 2;
        prices.push(basePrice);
        volumes.push(Math.floor(Math.random() * 1000000));
    }

    return {
        symbol,
        dates,
        prices,
        volumes
    };
}

function createOrUpdateCharts(data) {
    console.log('Updating charts with data:', data);

    if (!priceChart || !volumeChart) {
        // Create charts if they don't exist
        const priceCtx = document.getElementById('priceChart').getContext('2d');
        const volumeCtx = document.getElementById('volumeChart').getContext('2d');

        priceChart = new Chart(priceCtx, {
            type: 'line',
            data: {
                labels: data.dates,
                datasets: [{
                    label: `${data.symbol} Price`,
                    data: data.prices,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 750
                }
            }
        });

        volumeChart = new Chart(volumeCtx, {
            type: 'bar',
            data: {
                labels: data.dates,
                datasets: [{
                    label: `${data.symbol} Volume`,
                    data: data.volumes,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 750
                }
            }
        });
    } else {
        // Update existing charts
        priceChart.data.labels = data.dates;
        priceChart.data.datasets[0].data = data.prices;
        priceChart.update();

        volumeChart.data.labels = data.dates;
        volumeChart.data.datasets[0].data = data.volumes;
        volumeChart.update();
    }
}

function updateChartsWithData(data) {
    console.log('Updating charts with new period data:', data);
    createOrUpdateCharts(data);
}

async function updateChartsAndMap(symbol, period) {
    try {
        // Fetch new data for the selected period
        const response = await fetch(`/api/stock-data/${symbol}?period=${period}`);
        const newData = await response.json();

        // Update charts with new data
        updateCharts(newData);

        // Update map with new data
        updateMap(newData.locations); // Assuming the API returns location data

    } catch (error) {
        console.error('Error updating charts and map:', error);
    }
}

function updateMap(locations) {
    if (!currentMap) {
        console.error('Map not initialized');
        return;
    }

    // Clear existing markers
    currentMap.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
            currentMap.removeLayer(layer);
        }
    });

    // Add new markers based on the period data
    locations.forEach(location => {
        const marker = L.marker([location.lat, location.lng])
            .bindPopup(`
                <strong>${location.name}</strong><br>
                Value: ${location.value}<br>
                Date: ${location.date}
            `);
        marker.addTo(currentMap);
    });

    // Optional: Fit bounds to show all markers
    const bounds = L.latLngBounds(locations.map(loc => [loc.lat, loc.lng]));
    currentMap.fitBounds(bounds);
}

// For testing with mock data
function generateMockLocationData(period) {
    const locations = [
        { lat: 40.7128, lng: -74.0060, name: "New York", value: Math.random() * 1000, date: "2024-03-20" },
        { lat: 34.0522, lng: -118.2437, name: "Los Angeles", value: Math.random() * 1000, date: "2024-03-20" },
        { lat: 51.5074, lng: -0.1278, name: "London", value: Math.random() * 1000, date: "2024-03-20" },
        // Add more locations as needed
    ];
    return locations;
}

// For testing without API
function updateChartsAndMap(symbol, period) {
    // Generate mock data
    const mockData = {
        ...generateMockData(period),
        locations: generateMockLocationData(period)
    };

    // Update both charts and map
    updateCharts(mockData);
    updateMap(mockData.locations);
}

function generateMockData(period) {
    const dataPoints = {
        '1W': 7,
        '1M': 30,
        '3M': 90,
        '1Y': 365,
        'ALL': 1095
    };

    const numPoints = dataPoints[period] || 30;
    const dates = [];
    const prices = [];
    const volumes = [];

    for (let i = 0; i < numPoints; i++) {
        const date = new Date();
        date.setDate(date.getDate() - (numPoints - i));
        dates.push(date.toISOString().split('T')[0]);
        prices.push(Math.random() * 100 + 100); // Random price between 100-200
        volumes.push(Math.random() * 1000000); // Random volume
    }

    return { dates, prices, volumes };
}

function createInitialCharts(data) {
    const priceCtx = document.getElementById('priceChart').getContext('2d');
    const volumeCtx = document.getElementById('volumeChart').getContext('2d');

    priceChart = new Chart(priceCtx, {
        type: 'line',
        data: {
            labels: data.dates,
            datasets: [{
                label: 'Stock Price',
                data: data.prices,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });

    volumeChart = new Chart(volumeCtx, {
        type: 'bar',
        data: {
            labels: data.dates,
            datasets: [{
                label: 'Volume',
                data: data.volumes,
                backgroundColor: 'rgba(75, 192, 192, 0.2)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

function updateCharts(data) {
    console.log('Updating charts with new data:', data);

    if (priceChart) {
        priceChart.data.labels = data.dates;
        priceChart.data.datasets[0].data = data.prices;
        priceChart.update();
        console.log('Price chart updated');
    } else {
        console.error('Price chart not initialized');
    }

    if (volumeChart) {
        volumeChart.data.labels = data.dates;
        volumeChart.data.datasets[0].data = data.volumes;
        volumeChart.update();
        console.log('Volume chart updated');
    } else {
        console.error('Volume chart not initialized');
    }
}

function createChartPopup() {
    const popup = document.createElement('div');
    popup.id = 'stockChartPopup';
    popup.innerHTML = `
        <div class="chart-container">
            <div class="chart-header">
                <div class="company-info">
                    <h2 class="company-name"></h2>
                    <div class="price-details">
                        <span class="current-price"></span>
                        <span class="price-change"></span>
                    </div>
                </div>
                <div class="chart-controls">
                    <div class="timeframe-buttons">
                        <button class="active" data-period="1D">1D</button>
                        <button data-period="1W">1W</button>
                        <button data-period="1M">1M</button>
                        <button data-period="3M">3M</button>
                        <button data-period="1Y">1Y</button>
                        <button data-period="ALL">ALL</button>
                    </div>
                    <button class="close-chart">×</button>
                </div>
            </div>
            <div class="charts">
                <canvas id="priceChart"></canvas>
                <canvas id="volumeChart"></canvas>
            </div>
        </div>
    `;

    // Add styles
    const styles = document.createElement('style');
    styles.textContent = `
        #stockChartPopup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            backdrop-filter: blur(8px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .chart-container {
            width: 90%;
            max-width: 1200px;
            height: 85vh;
            background: linear-gradient(145deg, rgba(15, 23, 42, 0.98), rgba(30, 41, 59, 0.95));
            border-radius: 16px;
            padding: 24px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 24px;
            color: #fff;
        }
        .company-name {
            font-size: 24px;
            margin: 0 0 8px 0;
        }
        .price-details {
            font-size: 18px;
        }
        .timeframe-buttons {
            display: flex;
            gap: 8px;
        }
        .timeframe-buttons button {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .timeframe-buttons button.active {
            background: #7C3AED;
            border-color: transparent;
        }
        .close-chart {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: #fff;
            font-size: 24px;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            cursor: pointer;
            margin-left: 16px;
        }
        .charts {
            display: grid;
            grid-template-rows: 2fr 1fr;
            gap: 24px;
            height: calc(100% - 80px);
        }
    `;
    document.head.appendChild(styles);

    // Add close handler
    popup.querySelector('.close-chart').addEventListener('click', () => {
        popup.style.display = 'none';
    });

    // Add timeframe handlers
    popup.querySelectorAll('.timeframe-buttons button').forEach(button => {
        button.addEventListener('click', function() {
            popup.querySelectorAll('.timeframe-buttons button').forEach(b => 
                b.classList.remove('active'));
            this.classList.add('active');
            updateCharts(this.dataset.period);
        });
    });

    document.body.appendChild(popup);
    return popup;
}

function createPriceChart(data) {
    const ctx = document.getElementById('priceChart').getContext('2d');
    
    // Create professional gradients
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    const isPositive = data.change >= 0;

    if (isPositive) {
        // Green gradient for positive trend
        gradient.addColorStop(0, 'rgba(34, 197, 94, 0.25)');  // Bright green
        gradient.addColorStop(0.5, 'rgba(34, 197, 94, 0.15)');
        gradient.addColorStop(1, 'rgba(34, 197, 94, 0.02)');
    } else {
        // Red gradient for negative trend
        gradient.addColorStop(0, 'rgba(239, 68, 68, 0.25)');  // Bright red
        gradient.addColorStop(0.5, 'rgba(239, 68, 68, 0.15)');
        gradient.addColorStop(1, 'rgba(239, 68, 68, 0.02)');
    }

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: generateTimeLabels(50),
            datasets: [{
                label: 'Price',
                data: generatePriceData(data.price, 50),
                borderColor: isPositive ? '#22c55e' : '#ef4444',  // Solid green or red
                backgroundColor: gradient,
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 6,
                pointHoverBackgroundColor: isPositive ? '#15803d' : '#b91c1c',  // Darker green/red
                pointHoverBorderColor: '#fff',
                pointHoverBorderWidth: 2
            }]
        },
        options: {
            ...createChartOptions('Price'),
            plugins: {
                ...createChartOptions('Price').plugins,
                tooltip: {
                    ...createChartOptions('Price').plugins.tooltip,
                    callbacks: {
                        label: function(context) {
                            return `₹${context.parsed.y.toLocaleString('en-IN', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            })}`;
                        }
                    }
                }
            }
        }
    });
}

function createVolumeChart(data) {
    const ctx = document.getElementById('volumeChart').getContext('2d');
    
    // Create volume gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, 200);
    gradient.addColorStop(0, 'rgba(59, 130, 246, 0.30)');  // Bright blue
    gradient.addColorStop(0.5, 'rgba(59, 130, 246, 0.15)');
    gradient.addColorStop(1, 'rgba(59, 130, 246, 0.02)');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: generateTimeLabels(50),
            datasets: [{
                label: 'Volume',
                data: generateVolumeData(data.volume, 50),
                backgroundColor: gradient,
                hoverBackgroundColor: 'rgba(59, 130, 246, 0.4)',
                borderRadius: {
                    topLeft: 4,
                    topRight: 4
                },
                borderSkipped: false
            }]
        },
        options: {
            ...createChartOptions('Volume'),
            plugins: {
                ...createChartOptions('Volume').plugins,
                tooltip: {
                    ...createChartOptions('Volume').plugins.tooltip,
                    callbacks: {
                        label: function(context) {
                            return `Volume: ${context.parsed.y.toLocaleString()}`;
                        }
                    }
                }
            }
        }
    });
}

function createChartOptions(title) {
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                titleFont: {
                    size: 14,
                    weight: '600',
                    family: "'Inter', sans-serif"
                },
                bodyFont: {
                    size: 13,
                    family: "'Inter', sans-serif"
                },
                padding: {
                    top: 12,
                    right: 16,
                    bottom: 12,
                    left: 16
                },
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 1,
                displayColors: false
            }
        },
        scales: {
            y: {
                grid: {
                    color: 'rgba(255, 255, 255, 0.06)',
                    drawBorder: false
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)',
                    font: {
                        size: 11,
                        family: "'Inter', sans-serif"
                    }
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)',
                    font: {
                        size: 11,
                        family: "'Inter', sans-serif"
                    },
                    maxRotation: 0
                }
            }
        },
        interaction: {
            intersect: false,
            mode: 'index'
        },
        animations: {
            tension: {
                duration: 1000,
                easing: 'linear'
            }
        }
    };
}

// Helper functions for generating mock data
function generateTimeLabels(count) {
    return Array.from({length: count}, (_, i) => `${i}:00`);
}

function generatePriceData(basePrice, count) {
    return Array.from({length: count}, () => 
        basePrice + (Math.random() - 0.5) * basePrice * 0.02);
}

function generateVolumeData(baseVolume, count) {
    return Array.from({length: count}, () => 
        baseVolume * (0.5 + Math.random()));
}

// Add styles for new elements
const additionalStyles = `
    .company-details {
        color: rgba(255, 255, 255, 0.7);
        font-size: 14px;
        margin-top: 4px;
    }
    .sector, .industry {
        display: inline-block;
        padding: 2px 8px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 4px;
        margin: 0 2px;
    }
`;

// Add the new styles to the existing styleSheet
document.addEventListener('DOMContentLoaded', function() {
    const styleSheet = document.createElement('style');
    styleSheet.textContent = additionalStyles;
    document.head.appendChild(styleSheet);
});

// Function to fetch stock data for different time periods
async function fetchStockData(symbol, period) {
    try {
        const response = await fetch(`/api/stock-data/${symbol}?period=${period}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching stock data:', error);
        return null;
    }
}

// Function to update the price chart
function updatePriceChart(data) {
    // Assuming you're using a charting library like Chart.js
    if (priceChart) {  // priceChart should be defined globally or in accessible scope
        priceChart.data.labels = data.dates;
        priceChart.data.datasets[0].data = data.prices;
        priceChart.update();
    }
}

// Function to update the volume chart
function updateVolumeChart(data) {
    // Similar to updatePriceChart
    if (volumeChart) {  // volumeChart should be defined globally or in accessible scope
        volumeChart.data.labels = data.dates;
        volumeChart.data.datasets[0].data = data.volumes;
        volumeChart.update();
    }
}

// Function to format date range based on period
function getDateRange(period) {
    const end = new Date();
    const start = new Date();
    
    switch(period) {
        case '1W':
            start.setDate(end.getDate() - 7);
            break;
        case '1M':
            start.setMonth(end.getMonth() - 1);
            break;
        case '3M':
            start.setMonth(end.getMonth() - 3);
            break;
        case '1Y':
            start.setFullYear(end.getFullYear() - 1);
            break;
        case 'ALL':
            start.setFullYear(end.getFullYear() - 5); // Default to 5 years for ALL
            break;
        default:
            start.setMonth(end.getMonth() - 1); // Default to 1M
    }
    
    return {
        start: start.toISOString().split('T')[0],
        end: end.toISOString().split('T')[0]
    };
}

// Function to fetch historical data
async function fetchHistoricalData(symbol, period) {
    try {
        const dateRange = getDateRange(period);
        const response = await fetch(`/api/historical-data/${symbol}?start=${dateRange.start}&end=${dateRange.end}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching historical data:', error);
        return null;
    }
}

// Update the button click handlers
function setupPeriodButtons(symbol) {
    const periodButtons = document.querySelectorAll('[data-period]');
    periodButtons.forEach(button => {
        button.addEventListener('click', async () => {
            // Visual feedback for loading state
            button.disabled = true;
            periodButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            const period = button.getAttribute('data-period');
            try {
                const historicalData = await fetchHistoricalData(symbol, period);
                if (historicalData) {
                    updateCharts(historicalData);
                }
            } catch (error) {
                console.error('Error updating charts:', error);
            } finally {
                button.disabled = false;
            }
        });
    });
}

// Update the charts with new data
function updateCharts(data) {
    // Format data for charts
    const chartData = formatChartData(data);
    
    if (priceChart) {
        priceChart.data.labels = chartData.dates;
        priceChart.data.datasets[0].data = chartData.prices;
        priceChart.update();
    }
    
    if (volumeChart) {
        volumeChart.data.labels = chartData.dates;
        volumeChart.data.datasets[0].data = chartData.volumes;
        volumeChart.update();
    }
}

// Format data for charts
function formatChartData(data) {
    return {
        dates: data.map(item => item.date),
        prices: data.map(item => item.close),
        volumes: data.map(item => item.volume)
    };
} 