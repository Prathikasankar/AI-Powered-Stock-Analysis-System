import { createPriceChart } from '../static/js/stockChart.js';

// Single source of truth for company data
const companyData = new Map();

function showVisualization(data) {
    // Remove any existing popup first
    removeExistingPopup();
    
    // Create new popup
    const popup = document.createElement('div');
    popup.id = 'stockChartPopup';
    
    // Create popup with ONLY company name, NO spans
    popup.innerHTML = `
        <div class="chart-container">
            <div class="chart-header">
                <div class="company-info">
                    <h2 class="company-name">${data.name}</h2>
                </div>
                <div class="chart-controls">
                    <div class="timeframe-buttons">
                        <button class="active" data-period="1D">1D</button>
                        <button data-period="1W">1W</button>
                        <button data-period="1M">1M</button>
                        <button data-period="3M">3M</button>
                        <button data-period="1Y">1Y</button>
                        <button data-period="ALL">ALL</button>
                    </div>
                    <button class="close-chart">×</button>
                </div>
            </div>
            <div class="chart-area">
                <canvas id="priceChart"></canvas>
            </div>
        </div>
    `;
    
    // Add close handler
    popup.querySelector('.close-chart').addEventListener('click', () => {
        removeExistingPopup();
    });
    
    // Add to document and display
    document.body.appendChild(popup);
    popup.style.display = 'flex';
    
    // Create chart
    const priceCtx = document.getElementById('priceChart').getContext('2d');
    createPriceChart(priceCtx, data);
}

function removeExistingPopup() {
    const existing = document.getElementById('stockChartPopup');
    if (existing) {
        existing.remove();
    }
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    const cells = document.querySelectorAll('.stock-table td:first-child');
    
    cells.forEach(cell => {
        // Remove old listener
        const newCell = cell.cloneNode(true);
        cell.parentNode.replaceChild(newCell, cell);
        
        // Add single click handler
        newCell.style.cursor = 'pointer';
        newCell.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const data = {
                name: this.textContent.trim(),
                symbol: this.nextElementSibling.textContent.trim()
            };
            showVisualization(data);
        });
    });
});

// Styles without any span-related CSS
const styles = document.createElement('style');
styles.textContent = `
    #stockChartPopup {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.85);
        backdrop-filter: blur(8px);
        z-index: 1000;
        display: none;
        justify-content: center;
        align-items: center;
    }
    .chart-container {
        width: 90%;
        max-width: 1200px;
        height: 85vh;
        background: linear-gradient(145deg, rgba(15, 23, 42, 0.98), rgba(30, 41, 59, 0.95));
        border-radius: 16px;
        padding: 24px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    }
    .chart-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 24px;
    }
    .company-name {
        font-size: 24px;
        margin: 0;
        color: #fff;
    }
    .timeframe-buttons {
        display: flex;
        gap: 8px;
    }
    .timeframe-buttons button {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #fff;
        padding: 8px 16px;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    .timeframe-buttons button.active {
        background: #7C3AED;
        border-color: transparent;
    }
    .close-chart {
        background: rgba(255, 255, 255, 0.1);
        border: none;
        color: #fff;
        font-size: 24px;
        width: 36px;
        height: 36px;
        border-radius: 8px;
        cursor: pointer;
        margin-left: 16px;
    }
    .chart-area {
        height: calc(100% - 80px);
    }
`;
document.head.appendChild(styles);

// Helper functions for mock data
function generateRandomPrice() {
    return Math.random() * 1000 + 100;
}

function generateRandomChange() {
    return (Math.random() - 0.5) * 20;
}