from django.contrib import admin
from .models import User_register

# Register your models here.
admin.site.register(User_register)