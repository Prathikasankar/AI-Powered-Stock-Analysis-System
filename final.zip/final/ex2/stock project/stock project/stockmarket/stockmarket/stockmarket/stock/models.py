from django.db import models
from django.core.exceptions import ValidationError
from decimal import Decimal
from datetime import datetime
from .utils import get_real_time_price

class User_register(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.username

class Stock(models.Model):
    user = models.ForeignKey('User_register', on_delete=models.CASCADE)
    symbol = models.CharField(max_length=20)
    quantity = models.PositiveIntegerField()  # Changed to PositiveIntegerField
    purchase_price = models.DecimalField(max_digits=10, decimal_places=2)
    purchase_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def clean(self):
        if self.quantity <= 0:
            raise ValidationError('Quantity must be positive')
        if self.purchase_price <= 0:
            raise ValidationError('Purchase price must be positive')

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def get_ltp(self):
        """Get Last Traded Price"""
        price = get_real_time_price(self.symbol)
        return price if price else self.purchase_price

    def get_current_value(self):
        return Decimal(str(self.quantity)) * self.get_ltp()

    def get_pnl(self):
        """Calculate Profit/Loss"""
        return self.get_current_value() - (Decimal(str(self.quantity)) * self.purchase_price)

    def get_net_returns(self):
        """Calculate returns percentage"""
        initial_investment = Decimal(str(self.quantity)) * self.purchase_price
        if initial_investment == 0:
            return Decimal('0')
        return (self.get_pnl() / initial_investment) * Decimal('100')

    def __str__(self):
        return f"{self.symbol} - {self.quantity} shares"

    class Meta:
        unique_together = ['user', 'symbol']
        ordering = ['-created_at']

import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def ai_assistant_response(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'})
    
    try:
        data = json.loads(request.body)
        user_message = data.get('message', '').lower()
        user_id = request.session.get('user_id')
        
        if not user_id:
            return JsonResponse({'error': 'Please login first'})

        # Simple response logic for testing
        if 'strategy' in user_message:
            response = "Here are some investment strategies: Value Investing, Growth Investing, Dividend Investing, and Index Investing."
        else:
            response = "I'm here to help with your investment queries. Ask me anything about your portfolio!"

        return JsonResponse({
            'response': response,
            'timestamp': datetime.now().strftime('%H:%M')
        })

    except Exception as e:
        print(f"AI Assistant Error: {str(e)}")
        return JsonResponse({'error': 'Unable to process your request'})