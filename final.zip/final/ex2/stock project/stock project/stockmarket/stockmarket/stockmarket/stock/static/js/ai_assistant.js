document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chatMessages');
    const userMessageInput = document.getElementById('userMessage');
    const sendMessageBtn = document.getElementById('sendMessage');
    const minimizeBtn = document.getElementById('minimizeAssistant');
    const aiAssistant = document.getElementById('aiAssistant');

    let isMinimized = false;

    function addMessage(sender, content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        contentDiv.textContent = content;
        
        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.textContent = new Date().toLocaleTimeString();
        
        messageDiv.appendChild(contentDiv);
        messageDiv.appendChild(timeDiv);
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function sendMessage() {
        const message = userMessageInput.value.trim();
        if (!message) return;

        addMessage('user', message);
        userMessageInput.value = '';

        fetch('/stock/ai_assistant/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                addMessage('assistant', data.response);
            } else {
                addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
        });
    }

    minimizeBtn.addEventListener('click', () => {
        const assistantBody = aiAssistant.querySelector('.ai-assistant-body');
        if (isMinimized) {
            assistantBody.style.display = 'flex';
            minimizeBtn.innerHTML = '<i class="fas fa-minus"></i>';
        } else {
            assistantBody.style.display = 'none';
            minimizeBtn.innerHTML = '<i class="fas fa-plus"></i>';
        }
        isMinimized = !isMinimized;
    });

    sendMessageBtn.addEventListener('click', sendMessage);
    userMessageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});