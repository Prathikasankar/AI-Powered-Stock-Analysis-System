document.addEventListener('DOMContentLoaded', function() {
    const indicesTableBody = document.createElement('tbody');
    indicesTableBody.id = 'indicesTableBody';
    document.querySelector('.indices-table').appendChild(indicesTableBody);

    // Market data configuration
    const marketData = {
        bse: {
            SENSEX: { base: 73500, range: 1000 },
            BANKEX: { base: 48000, range: 800 },
            IT: { base: 35000, range: 600 },
            AUTO: { base: 42000, range: 700 },
            FMCG: { base: 45000, range: 750 },
            METAL: { base: 25000, range: 500 },
            OIL: { base: 38000, range: 600 },
            POWER: { base: 28000, range: 450 },
            HEALTHCARE: { base: 32000, range: 550 },
            CONSUMER: { base: 41000, range: 650 }
        },
        nse: {
            NIFTY: { base: 22400, range: 400 },
            BANK: { base: 46500, range: 800 },
            IT: { base: 32500, range: 500 },
            AUTO: { base: 18900, range: 300 },
            FMCG: { base: 52000, range: 850 },
            METAL: { base: 8500, range: 200 },
            PHARMA: { base: 15000, range: 300 },
            REALTY: { base: 12000, range: 250 },
            MIDCAP: { base: 42000, range: 700 },
            SMALLCAP: { base: 11000, range: 200 }
        }
    };

    // Popup elements
    const hoverPopup = document.getElementById('indexPopup');
    const detailsPopup = document.getElementById('indexDetailsPopup');
    const closePopupBtn = detailsPopup?.querySelector('.close-popup');
    let chart = null;

    function initializePopupElements() {
        if (!detailsPopup) {
            console.error('Popup element with ID "indexDetailsPopup" not found in the DOM.');
            return false;
        }

        if (closePopupBtn) {
            closePopupBtn.addEventListener('click', hideDetailsPopup);
        }

        detailsPopup.addEventListener('click', (e) => {
            if (e.target === detailsPopup) {
                hideDetailsPopup();
            }
        });

        detailsPopup.querySelector('.popup-content')?.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        return true;
    }

    function showPopup(quote, event) {
        // Get position of hovered element
        const rect = event.target.closest('.index-name').getBoundingClientRect();
        
        // Calculate popup position
        const popupX = rect.right + 20;
        const popupY = Math.max(rect.top, 10);

        // Update popup content
        hoverPopup.querySelector('.popup-title').textContent = quote.name;
        hoverPopup.querySelector('.market-tag').textContent = 
            quote.symbol.includes('BSE') ? 'BSE' : 'NSE';
        
        hoverPopup.querySelector('.price-value').textContent = 
            `₹${quote.c.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
        
        const changeValue = hoverPopup.querySelector('.change-value');
        changeValue.textContent = 
            `${quote.d >= 0 ? '+' : ''}${quote.d.toFixed(2)} (${quote.dp.toFixed(2)}%)`;
        changeValue.className = 
            `stat-value change-value ${quote.d >= 0 ? 'positive' : 'negative'}`;
        
        hoverPopup.querySelector('.range-value').textContent = 
            `₹${quote.l.toLocaleString('en-IN', {minimumFractionDigits: 2})} - ₹${quote.h.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
        
        hoverPopup.querySelector('.volume-value').textContent = 
            quote.v.toLocaleString('en-IN');

        // Position popup
        hoverPopup.style.left = `${popupX}px`;
        hoverPopup.style.top = `${popupY}px`;
        
        // Show popup
        hoverPopup.classList.add('visible');

        // Create/update chart
        if (chart) {
            chart.destroy();
        }

        const ctx = document.getElementById('miniChart').getContext('2d');
        chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['5m', '4m', '3m', '2m', '1m', 'Now'],
                datasets: [{
                    data: generateChartData(quote),
                    borderColor: quote.d >= 0 ? '#22c55e' : '#ef4444',
                    backgroundColor: quote.d >= 0 ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: 'rgba(255, 255, 255, 0.5)' }
                    },
                    y: {
                        display: false
                    }
                }
            }
        });
    }

    function hidePopup() {
        hoverPopup.classList.remove('visible');
    }

    function generateDummyData() {
        return [
            // BSE Indices
            {
                name: "SENSEX",
                symbol: "BSE:SENSEX",
                c: 73500.50,
                d: 650.75,
                dp: 0.89,
                h: 73800.25,
                l: 73100.50,
                v: 12500000
            },
            {
                name: "BSE BANKEX",
                symbol: "BSE:BANKEX",
                c: 48250.75,
                d: 425.30,
                dp: 0.89,
                h: 48500.00,
                l: 47900.25,
                v: 8500000
            },
            {
                name: "BSE IT",
                symbol: "BSE:IT",
                c: 35800.25,
                d: -320.50,
                dp: -0.89,
                h: 36100.75,
                l: 35600.00,
                v: 5200000
            },
            {
                name: "BSE AUTO",
                symbol: "BSE:AUTO",
                c: 42600.80,
                d: 380.25,
                dp: 0.90,
                h: 42800.50,
                l: 42400.25,
                v: 4800000
            },
            {
                name: "BSE FMCG",
                symbol: "BSE:FMCG",
                c: 45200.30,
                d: -290.45,
                dp: -0.64,
                h: 45500.75,
                l: 45000.50,
                v: 3900000
            },
            {
                name: "BSE METAL",
                symbol: "BSE:METAL",
                c: 25400.60,
                d: 225.30,
                dp: 0.89,
                h: 25600.25,
                l: 25200.75,
                v: 6200000
            },
            {
                name: "BSE OIL & GAS",
                symbol: "BSE:OIL&GAS",
                c: 38500.25,
                d: -420.50,
                dp: -1.08,
                h: 38900.75,
                l: 38300.50,
                v: 5500000
            },
            {
                name: "BSE POWER",
                symbol: "BSE:POWER",
                c: 28300.45,
                d: 310.25,
                dp: 1.11,
                h: 28500.75,
                l: 28100.50,
                v: 7200000
            },
            {
                name: "BSE HEALTHCARE",
                symbol: "BSE:HEALTHCARE",
                c: 32600.75,
                d: -280.50,
                dp: -0.85,
                h: 32900.25,
                l: 32400.50,
                v: 4100000
            },
            {
                name: "BSE CONSUMER DURABLES",
                symbol: "BSE:CONSUMER",
                c: 41300.90,
                d: 425.75,
                dp: 1.04,
                h: 41500.50,
                l: 41100.25,
                v: 3800000
            },
            {
                name: "BSE REALTY",
                symbol: "BSE:REALTY",
                c: 12500.25,
                d: 150.50,
                dp: 1.22,
                h: 12600.75,
                l: 12400.50,
                v: 4500000
            },
            {
                name: "BSE MIDCAP",
                symbol: "BSE:MIDCAP",
                c: 42800.50,
                d: -380.25,
                dp: -0.88,
                h: 43100.75,
                l: 42600.25,
                v: 6800000
            },
            {
                name: "BSE SMALLCAP",
                symbol: "BSE:SMALLCAP",
                c: 11200.75,
                d: 120.50,
                dp: 1.09,
                h: 11300.25,
                l: 11100.50,
                v: 7500000
            },
            // NSE Indices
            {
                name: "NIFTY 50",
                symbol: "NSE:NIFTY",
                c: 22400.50,
                d: 195.75,
                dp: 0.88,
                h: 22500.25,
                l: 22300.50,
                v: 15500000
            },
            {
                name: "NIFTY BANK",
                symbol: "NSE:BANK",
                c: 46500.25,
                d: 420.50,
                dp: 0.91,
                h: 46700.75,
                l: 46300.50,
                v: 9200000
            },
            {
                name: "NIFTY IT",
                symbol: "NSE:IT",
                c: 32500.75,
                d: -290.25,
                dp: -0.89,
                h: 32800.50,
                l: 32400.25,
                v: 5800000
            },
            {
                name: "NIFTY AUTO",
                symbol: "NSE:AUTO",
                c: 18900.50,
                d: 165.25,
                dp: 0.88,
                h: 19000.75,
                l: 18800.25,
                v: 4200000
            },
            {
                name: "NIFTY FMCG",
                symbol: "NSE:FMCG",
                c: 52000.25,
                d: -450.50,
                dp: -0.86,
                h: 52400.75,
                l: 51800.50,
                v: 3600000
            },
            {
                name: "NIFTY METAL",
                symbol: "NSE:METAL",
                c: 8500.75,
                d: 95.25,
                dp: 1.13,
                h: 8600.50,
                l: 8400.25,
                v: 8200000
            },
            {
                name: "NIFTY PHARMA",
                symbol: "NSE:PHARMA",
                c: 15000.50,
                d: -125.75,
                dp: -0.83,
                h: 15200.25,
                l: 14900.50,
                v: 4900000
            },
            {
                name: "NIFTY REALTY",
                symbol: "NSE:REALTY",
                c: 12000.25,
                d: 135.50,
                dp: 1.14,
                h: 12100.75,
                l: 11900.50,
                v: 5100000
            },
            {
                name: "NIFTY MIDCAP 100",
                symbol: "NSE:MIDCAP",
                c: 42000.75,
                d: -365.25,
                dp: -0.86,
                h: 42300.50,
                l: 41800.25,
                v: 7200000
            },
            {
                name: "NIFTY SMALLCAP 100",
                symbol: "NSE:SMALLCAP",
                c: 11000.50,
                d: 115.75,
                dp: 1.06,
                h: 11100.25,
                l: 10900.50,
                v: 6500000
            },
            {
                name: "NIFTY MEDIA",
                symbol: "NSE:MEDIA",
                c: 2450.25,
                d: -28.50,
                dp: -1.15,
                h: 2480.75,
                l: 2430.50,
                v: 3200000
            },
            {
                name: "NIFTY PSU BANK",
                symbol: "NSE:PSUBANK",
                c: 6800.75,
                d: 75.25,
                dp: 1.12,
                h: 6850.50,
                l: 6750.25,
                v: 5800000
            },
            {
                name: "NIFTY ENERGY",
                symbol: "NSE:ENERGY",
                c: 35200.50,
                d: 310.75,
                dp: 0.89,
                h: 35400.25,
                l: 35000.50,
                v: 4600000
            },
            {
                name: "NIFTY INFRA",
                symbol: "NSE:INFRA",
                c: 28500.25,
                d: -245.50,
                dp: -0.85,
                h: 28700.75,
                l: 28400.50,
                v: 5300000
            },
            {
                name: "NIFTY CONSUMPTION",
                symbol: "NSE:CONSUMPTION",
                c: 31200.75,
                d: 285.25,
                dp: 0.92,
                h: 31400.50,
                l: 31100.25,
                v: 3900000
            },
            {
                name: "NIFTY PSE",
                symbol: "NSE:PSE",
                c: 24800.50,
                d: -215.75,
                dp: -0.86,
                h: 25000.25,
                l: 24700.50,
                v: 4200000
            },
            {
                name: "NIFTY FINANCIAL SERVICES",
                symbol: "NSE:FINANCIAL",
                c: 55200.25,
                d: 485.50,
                dp: 0.89,
                h: 55400.75,
                l: 55000.50,
                v: 6800000
            }
        ];
    }

    function displayIndices(data) {
        const tableBody = document.querySelector('.indices-table tbody');
        if (!tableBody) return;

        tableBody.innerHTML = '';

        data.forEach(quote => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>
                    <div class="index-name" data-symbol="${quote.symbol}">
                        <span class="symbol">${quote.name}</span>
                        <span class="market-tag">${quote.symbol.includes('BSE') ? 'BSE' : 'NSE'}</span>
                    </div>
                </td>
                <td class="price">₹${quote.c.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
                <td class="change ${quote.d >= 0 ? 'positive' : 'negative'}">
                    ${quote.d >= 0 ? '+' : ''}${quote.d.toFixed(2)}
                    <span class="percent">(${quote.dp.toFixed(2)}%)</span>
                </td>
                <td>₹${quote.h.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
                <td>₹${quote.l.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
                <td>${quote.v.toLocaleString('en-IN')}</td>
            `;

            const indexName = row.querySelector('.index-name');
            indexName?.addEventListener('click', () => {
                console.log('Index clicked:', quote.name); // Debug log
                showDetailsPopup(quote);
            });

            tableBody.appendChild(row);
        });
    }

    function generateChartData(quote) {
        const trend = quote.d >= 0;
        const basePrice = quote.c - quote.d;
        return [
            basePrice,
            basePrice + (quote.d * 0.2),
            basePrice + (quote.d * 0.4),
            basePrice + (quote.d * 0.6),
            basePrice + (quote.d * 0.8),
            quote.c
        ];
    }

    const marketButtons = document.querySelectorAll('.market-type-btn');
    let currentMarket = 'all';

    function filterIndices(market) {
        currentMarket = market;
        const data = generateDummyData();
        
        // Filter data based on selected market
        const filteredData = market === 'all' ? 
            data : 
            data.filter(item => item.symbol.startsWith(market.toUpperCase()));
            
        displayIndices(filteredData);
        
        // Update UI state
        marketButtons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.market === market);
        });

        // Update header if it exists
        const headerText = document.querySelector('.header-left h1');
        if (headerText) {
            headerText.textContent = market === 'all' ? 
                'Indian Stock Market Indices' : 
                `${market.toUpperCase()} Market Indices`;
        }
    }

    // Single event listener setup for market buttons
    marketButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterIndices(button.dataset.market);
        });
    });

    // Initialize with all indices
    filterIndices('all');

    // Refresh button click handler
    document.querySelector('.refresh-btn')?.addEventListener('click', () => {
        displayIndices(generateDummyData());
    });

    // Auto refresh every minute
    setInterval(() => displayIndices(generateDummyData()), 60000);

    // Function to show the popup
    function showDetailsPopup(quote) {
        if (!detailsPopup) {
            console.error('Popup element not found');
            return;
        }

        try {
            const stockName = detailsPopup.querySelector('.stock-name');
            const priceBadge = detailsPopup.querySelector('.price-badge');
            const changeBadge = detailsPopup.querySelector('.change-badge');
            const volumeValue = detailsPopup.querySelector('.volume-value');
            const rangeValue = detailsPopup.querySelector('.range-value');

            if (stockName) stockName.textContent = quote.name;
            if (priceBadge) priceBadge.textContent = `₹${quote.c.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
            
            if (changeBadge) {
                const changeText = `${quote.d >= 0 ? '+' : ''}${quote.d.toFixed(2)} (${quote.dp.toFixed(2)}%)`;
                changeBadge.textContent = changeText;
                changeBadge.className = `change-badge ${quote.d >= 0 ? 'positive' : 'negative'}`;
            }

            if (volumeValue) volumeValue.textContent = quote.v.toLocaleString('en-IN');
            if (rangeValue) rangeValue.textContent = `₹${quote.l.toLocaleString('en-IN')} - ₹${quote.h.toLocaleString('en-IN')}`;

            // Show popup
            detailsPopup.classList.add('visible');
            document.body.style.overflow = 'hidden';
        } catch (error) {
            console.error('Error showing popup:', error);
        }
    }

    // Function to hide the popup
    function hideDetailsPopup() {
        if (!detailsPopup) return;
        detailsPopup.classList.remove('visible');
        document.body.style.overflow = '';
    }

    // Set up event listeners only once
    if (detailsPopup) {
        const closeBtn = detailsPopup.querySelector('.close-popup');
        if (closeBtn) {
            closeBtn.addEventListener('click', hideDetailsPopup);
        }

        detailsPopup.addEventListener('click', (e) => {
            if (e.target === detailsPopup) {
                hideDetailsPopup();
            }
        });
    }

    // Initialize popup elements
    initializePopupElements();

    // Generate initial data
    const initialData = generateDummyData();
    displayIndices(initialData);
});