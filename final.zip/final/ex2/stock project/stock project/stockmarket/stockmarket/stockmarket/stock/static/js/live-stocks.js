// Live Stocks Page JavaScript
document.addEventListener('DOMContentLoaded', () => {
    initializeStockData();
    setupEventListeners();
    startLiveUpdates();
    createMiniCharts();
    initializeMarketOverview();
    initializeStockTable();
    initializeMarketDepth(symbols[0]);
});

// Initialize stock data
function initializeStockData() {
    const stocksData = [
        {
            symbol: 'RELIANCE',
            company: 'Reliance Industries',
            ltp: 2890.30,
            change: 2.15,
            volume: '3.4M',
            high52: 2950.00,
            low52: 1987.00,
            marketCap: '1,856,789',
            pe: 22.5
        },
        {
            symbol: 'TCS',
            company: 'Tata Consultancy Services',
            ltp: 3890.60,
            change: 1.65,
            volume: '980K',
            high52: 4045.00,
            low52: 3120.00,
            marketCap: '1,234,567',
            pe: 28.4
        },
        // Add more stock data here
    ];

    updateStocksTable(stocksData);
}

// Update stocks table
function updateStocksTable(data) {
    const tableBody = document.getElementById('stocksTableBody');
    tableBody.innerHTML = data.map(stock => `
        <tr data-symbol="${stock.symbol}">
            <td>${stock.symbol}</td>
            <td>${stock.company}</td>
            <td class="price">${stock.ltp.toFixed(2)}</td>
            <td class="${stock.change >= 0 ? 'up' : 'down'}">
                ${stock.change >= 0 ? '+' : ''}${stock.change}%
            </td>
            <td>${stock.volume}</td>
            <td>${stock.high52.toFixed(2)}</td>
            <td>${stock.low52.toFixed(2)}</td>
            <td>${stock.marketCap}</td>
            <td>${stock.pe}</td>
        </tr>
    `).join('');
}

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    document.getElementById('stockSearch').addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('#stocksTableBody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });

    // Filter by sector
    document.getElementById('sectorFilter').addEventListener('change', (e) => {
        // Implement sector filtering
    });

    // Filter by market cap
    document.getElementById('marketCapFilter').addEventListener('change', (e) => {
        // Implement market cap filtering
    });

    // View options
    document.querySelectorAll('.view-options button').forEach(button => {
        button.addEventListener('click', (e) => {
            document.querySelectorAll('.view-options button').forEach(btn => {
                btn.classList.remove('active');
            });
            e.target.classList.add('active');
            // Implement view change logic
        });
    });
}

// Simulate live updates
function startLiveUpdates() {
    setInterval(() => {
        const prices = document.querySelectorAll('.price');
        prices.forEach(price => {
            const currentPrice = parseFloat(price.textContent);
            const change = (Math.random() - 0.5) * 10;
            const newPrice = currentPrice + change;
            price.textContent = newPrice.toFixed(2);
            
            const changeCell = price.nextElementSibling;
            const changePercent = (change / currentPrice * 100).toFixed(2);
            changeCell.textContent = `${changePercent >= 0 ? '+' : ''}${changePercent}%`;
            changeCell.className = changePercent >= 0 ? 'up' : 'down';
        });
    }, 5000);
}

// Function to update market depth data
function updateMarketDepth(data) {
    const buyDepth = document.getElementById('buyDepth');
    const sellDepth = document.getElementById('sellDepth');

    buyDepth.innerHTML = data.bids.map(bid => `
        <div class="depth-row">
            <span class="price">${bid.price}</span>
            <span class="quantity">${bid.quantity}</span>
        </div>
    `).join('');

    sellDepth.innerHTML = data.asks.map(ask => `
        <div class="depth-row">
            <span class="price">${ask.price}</span>
            <span class="quantity">${ask.quantity}</span>
        </div>
    `).join('');
}

// Add hover pause functionality
const tickerContent = document.getElementById("ticker-content");
if (tickerContent) {
    tickerContent.addEventListener('mouseover', () => {
        tickerContent.style.animationPlayState = 'paused';
    });
    
    tickerContent.addEventListener('mouseout', () => {
        tickerContent.style.animationPlayState = 'running';
    });
}

// Add this function to your existing live-stocks.js
function createMiniCharts() {
    const chartElements = document.querySelectorAll('.chart-mini');
    
    chartElements.forEach((element) => {
        const canvas = document.createElement('canvas');
        element.appendChild(canvas);
        const ctx = canvas.getContext('2d');
        
        // Generate random data points
        const dataPoints = Array.from({length: 20}, () => 
            Math.random() * 40 + 30
        );
        
        // Create gradient
        const gradient = ctx.createLinearGradient(0, 0, 0, 60);
        const parentCard = element.closest('.market-card');
        const changeElement = parentCard.querySelector('.change');
        const isUp = changeElement && changeElement.classList.contains('up');
        
        if (isUp) {
            gradient.addColorStop(0, 'rgba(239, 68, 68, 0.2)');   // Red with opacity
            gradient.addColorStop(1, 'rgba(239, 68, 68, 0)');
        } else {
            gradient.addColorStop(0, 'rgba(34, 197, 94, 0.2)');   // Green with opacity
            gradient.addColorStop(1, 'rgba(34, 197, 94, 0)');
        }

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from({length: 20}, (_, i) => ''),
                datasets: [{
                    data: dataPoints,
                    borderColor: isUp ? '#ef4444' : '#22c55e',
                    borderWidth: 2,
                    backgroundColor: gradient,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        display: false
                    },
                    y: {
                        display: false,
                        min: Math.min(...dataPoints) * 0.95,
                        max: Math.max(...dataPoints) * 1.05
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                }
            }
        });
    });
}

// Initialize Finnhub client with your API key
const finnhub = new finnhub.api('YOUR_FINNHUB_API_KEY');

// Stock symbols to track
const symbols = ['RELIANCE.BSE', 'TCS.BSE', 'HDFCBANK.BSE', 'INFY.BSE', 'ICICIBANK.BSE'];

// WebSocket connection
const socket = new WebSocket('wss://ws.finnhub.io?token=YOUR_FINNHUB_API_KEY');

// Connection opened -> Subscribe to symbols
socket.addEventListener('open', function () {
    symbols.forEach(symbol => {
        socket.send(JSON.stringify({'type': 'subscribe', 'symbol': symbol}));
    });
});

// Listen for messages
socket.addEventListener('message', function (event) {
    const data = JSON.parse(event.data);
    if (data.type === 'trade') {
        updateStockData(data);
    }
});

function updateStockData(data) {
    const stockRow = document.querySelector(`tr[data-symbol="${data.symbol}"]`);
    if (stockRow) {
        // Update price
        const priceCell = stockRow.querySelector('.stock-price');
        const oldPrice = parseFloat(priceCell.textContent);
        const newPrice = data.data[0].p;
        
        // Calculate change
        const change = ((newPrice - oldPrice) / oldPrice) * 100;
        
        // Update UI
        priceCell.textContent = newPrice.toFixed(2);
        const changeCell = stockRow.querySelector('.stock-change');
        changeCell.textContent = `${change >= 0 ? '+' : ''}${change.toFixed(2)}%`;
        changeCell.className = `stock-change ${change >= 0 ? 'up' : 'down'}`;
        
        // Update mini chart
        updateMiniChart(data.symbol, newPrice);
        
        // Update last updated time
        document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString();
    }
}

// Initialize market overview cards with real data
async function initializeMarketOverview() {
    try {
        const indices = ['NIFTY 50', 'SENSEX', 'BANKNIFTY'];
        const cards = document.querySelectorAll('.market-card');
        
        for (let i = 0; i < indices.length; i++) {
            const quote = await finnhub.quote(indices[i]);
            const card = cards[i];
            
            card.querySelector('.price').textContent = quote.c.toFixed(2);
            const change = ((quote.c - quote.pc) / quote.pc * 100);
            card.querySelector('.change').textContent = `${change >= 0 ? '+' : ''}${change.toFixed(2)}%`;
            card.querySelector('.change').className = `change ${change >= 0 ? 'up' : 'down'}`;
            
            // Initialize mini chart
            initializeMiniChart(card.querySelector('.chart-mini'), quote.t);
        }
    } catch (error) {
        console.error('Error initializing market overview:', error);
    }
}

// Initialize stock table with real data
async function initializeStockTable() {
    try {
        const tableBody = document.getElementById('stocksTableBody');
        tableBody.innerHTML = '';
        
        for (const symbol of symbols) {
            const quote = await finnhub.quote(symbol);
            const profile = await finnhub.companyProfile2({'symbol': symbol});
            
            const row = document.createElement('tr');
            row.setAttribute('data-symbol', symbol);
            
            row.innerHTML = `
                <td>${symbol}</td>
                <td>${profile.name}</td>
                <td class="stock-price">${quote.c.toFixed(2)}</td>
                <td class="stock-change ${quote.dp >= 0 ? 'up' : 'down'}">
                    ${quote.dp >= 0 ? '+' : ''}${quote.dp.toFixed(2)}%
                </td>
                <td>${(quote.v/1000000).toFixed(2)}M</td>
                <td>${quote.h.toFixed(2)}</td>
                <td>${quote.l.toFixed(2)}</td>
                <td>${(profile.marketCapitalization/1000).toFixed(2)}B</td>
                <td>${profile.peRatio?.toFixed(2) || 'N/A'}</td>
            `;
            
            tableBody.appendChild(row);
        }
    } catch (error) {
        console.error('Error initializing stock table:', error);
    }
}

// Initialize market depth
function initializeMarketDepth(symbol) {
    finnhub.marketDepth(symbol, (error, data) => {
        if (error) {
            console.error('Error fetching market depth:', error);
            return;
        }
        
        updateMarketDepth(data);
    });
}

// Call the function when the document is loaded
document.addEventListener('DOMContentLoaded', () => {
    createMiniCharts();
    // ... your other existing code ...
});