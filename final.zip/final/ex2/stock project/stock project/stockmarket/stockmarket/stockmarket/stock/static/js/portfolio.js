document.addEventListener('DOMContentLoaded', function() {
    initializePortfolio();
    setupCharts();
    setupEventListeners();
    startLiveUpdates();
    initializeBenchmarkChart();
    initializePortfolioChart();
    initializeAIAssistant();
    initializeChat();

    const addModal = document.getElementById('addStockModal');
    const addStockBtn = document.querySelector('#addStockBtn');
    const closeBtn = document.querySelector('.close');
    const addStockForm = document.getElementById('addStockForm');
    const editModal = document.getElementById('editModal');
    const editStockForm = document.getElementById('editStockForm');

    // Show add stock modal
    if (addStockBtn) {
        addStockBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (addModal) {
                addModal.classList.add('show');
            }
        });
    }

    // Close modals when clicking close button or outside
    document.querySelectorAll('.close').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                modal.classList.remove('show');
            }
        });
    });

    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('show');
        }
    });

    // Add stock form submission
    if (addStockForm) {
        addStockForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            try {
                const formData = new FormData(this);
                const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]');
                
                if (!csrfToken) {
                    throw new Error('CSRF token not found');
                }
                
                formData.append('csrfmiddlewaretoken', csrfToken.value);

                const response = await fetch('/stock/add_stock/', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (response.ok) {
                    addModal.classList.remove('show');
                    this.reset();
                    window.location.reload();
                } else {
                    throw new Error(data.error || 'Failed to add stock');
                }
            } catch (error) {
                console.error('Error:', error);
                alert(error.message || 'Error adding stock. Please try again.');
            }
        });
    }

    // Edit button handler
    document.addEventListener('click', function(e) {
        const editBtn = e.target.closest('.btn-edit');
        if (editBtn && editModal) {
            e.preventDefault();
            e.stopPropagation();
            
            const stockId = editBtn.getAttribute('data-stock-id');
            const symbol = editBtn.getAttribute('data-symbol');
            const quantity = editBtn.getAttribute('data-quantity');
            const price = editBtn.getAttribute('data-price');
            const date = editBtn.getAttribute('data-date');

            if (!stockId) {
                console.error('No stock ID found');
                return;
            }

            // Populate edit form
            document.getElementById('editStockId').value = stockId;
            document.getElementById('editSymbol').value = symbol;
            document.getElementById('editQuantity').value = quantity;
            document.getElementById('editPrice').value = price;
            document.getElementById('editDate').value = date || '';

            editModal.classList.add('show');
        }
    });

    // Edit form submission handler
    if (editStockForm) {
        editStockForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const stockId = document.getElementById('editStockId').value;
            const formData = {
                action: 'update',
                quantity: document.getElementById('editQuantity').value,
                purchase_price: document.getElementById('editPrice').value,
                purchase_date: document.getElementById('editDate').value
            };

            try {
                const response = await fetch(`/stock/get_stock/${stockId}/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                    },
                    body: JSON.stringify(formData)
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data.success) {
                    const row = document.querySelector(`tr[data-stock-id="${stockId}"]`);
                    if (row) {
                        const symbol = document.getElementById('editSymbol').value;
                        const quantity = parseInt(formData.quantity);
                        const purchasePrice = parseFloat(formData.purchase_price);
                        const currentPrice = parseFloat(data.current_price);

                        // Update row with new values
                        row.innerHTML = `
                            <td>${symbol}</td>
                            <td>${quantity}</td>
                            <td>₹${purchasePrice.toFixed(2)}</td>
                            <td>₹${currentPrice.toFixed(2)}</td>
                            <td>₹${(quantity * currentPrice).toFixed(2)}</td>
                            <td class="${data.pnl >= 0 ? 'profit' : 'loss'}">
                                ${data.pnl >= 0 ? '+' : ''}₹${Math.abs(data.pnl).toFixed(2)}
                            </td>
                            <td class="${data.returns >= 0 ? 'profit' : 'loss'}">
                                ${data.returns >= 0 ? '+' : ''}${data.returns.toFixed(2)}%
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-edit" 
                                        data-stock-id="${stockId}"
                                        data-symbol="${symbol}"
                                        data-quantity="${quantity}"
                                        data-price="${purchasePrice}"
                                        data-date="${formData.purchase_date}">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn-delete" data-stock-id="${stockId}">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        `;
                    }

                    // Close the modal
                    document.getElementById('editModal').style.display = 'none';
                    
                    // Show success message
                    alert('Stock updated successfully');
                } else {
                    throw new Error(data.error || 'Failed to update stock');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Error updating stock: ' + error.message);
            }
        });
    }

    // Single delete button handler with event delegation
    document.removeEventListener('click', deleteButtonHandler); // Remove any existing handlers
    const deleteButtonHandler = async function(e) {
        const deleteBtn = e.target.closest('.btn-delete');
        if (!deleteBtn) return;

        e.preventDefault();
        e.stopPropagation();
        
        const stockId = deleteBtn.getAttribute('data-stock-id');
        if (!stockId) return;

        if (confirm('Are you sure you want to delete this stock?')) {
            try {
                const response = await fetch(`/stock/get_stock/${stockId}/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                    },
                    body: JSON.stringify({ action: 'delete' })
                });

                const data = await response.json();
                if (data.success) {
                    const row = deleteBtn.closest('tr');
                    if (row) row.remove();
                } else {
                    throw new Error(data.error || 'Failed to delete stock');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Error deleting stock. Please try again.');
            }
        }
    };

    document.addEventListener('click', deleteButtonHandler);

    // Remove any other delete button event listeners
    document.querySelectorAll('.btn-delete').forEach(button => {
        const oldHandler = button.onclick;
        if (oldHandler) {
            button.removeEventListener('click', oldHandler);
        }
    });

    // Initialize AI recommendations
    try {
        updatePortfolioAnalysis();
        
        const refreshBtn = document.getElementById('refreshRecommendations');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', function() {
                this.classList.add('rotating');
                updatePortfolioAnalysis().finally(() => {
                    this.classList.remove('rotating');
                });
            });
        }
    } catch (error) {
        console.error('Initialization error:', error);
        showError('Failed to initialize portfolio analysis');
    }

    // Add sort functionality
    const sortSelect = document.getElementById('sortHoldings');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortHoldingsTable(this.value);
        });
    }

    // Add search functionality
    const searchInput = document.getElementById('stockSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#holdingsTableBody tr');

            rows.forEach(row => {
                if (row.id === 'no-stocks-row') return;
                
                const symbol = row.querySelector('.stock-symbol').textContent.toLowerCase();
                if (symbol.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});

// Initialize Portfolio Data
function initializePortfolio() {
    const mockHoldings = [
        {
            symbol: 'RELIANCE',
            quantity: 100,
            avgCost: 2450.75,
            ltp: 2890.30,
            currentValue: 289030,
            pnl: 43955,
            returns: 17.93
        },
        {
            symbol: 'TCS',
            quantity: 50,
            avgCost: 3450.00,
            ltp: 3890.60,
            currentValue: 194530,
            pnl: 22030,
            returns: 12.75
        },
        {
            symbol: 'INFY',
            quantity: 75,
            avgCost: 1580.25,
            ltp: 1690.80,
            currentValue: 126810,
            pnl: 8291,
            returns: 6.99
        }
    ];

    updateHoldingsTable(mockHoldings);
}

// Setup Charts
function setupCharts() {
    // Portfolio Performance Chart
    const performanceCtx = document.getElementById('portfolioChart').getContext('2d');
    new Chart(performanceCtx, {
        type: 'line',
        data: {
            labels: generateDateLabels(30),
            datasets: [{
                label: 'Portfolio Value',
                data: generatePerformanceData(30),
                borderColor: '#4a90e2',
                backgroundColor: 'rgba(74, 144, 226, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Sector Distribution Chart
    const sectorCtx = document.getElementById('sectorChart').getContext('2d');
    new Chart(sectorCtx, {
        type: 'doughnut',
        data: {
            labels: ['IT', 'Banking', 'Pharma', 'Auto', 'FMCG'],
            datasets: [{
                data: [30, 25, 15, 20, 10],
                backgroundColor: [
                    '#4a90e2',
                    '#67b26f',
                    '#f953c6',
                    '#f9d423',
                    '#8e44ad'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Event Listeners
function setupEventListeners() {
    // Time Filter Buttons
    document.querySelectorAll('.time-filter').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelector('.time-filter.active').classList.remove('active');
            this.classList.add('active');
            updateChartData(this.textContent);
        });
    });

    // Add Stock Modal
    const modal = document.getElementById('addStockModal');
    const addStockBtn = document.getElementById('addStockBtn');
    const closeBtn = document.querySelector('.close');

    addStockBtn.onclick = () => modal.style.display = 'block';
    closeBtn.onclick = () => modal.style.display = 'none';
    window.onclick = (e) => {
        if (e.target == modal) modal.style.display = 'none';
    };

    // Add Stock Form
    document.getElementById('addStockForm').onsubmit = function(e) {
        e.preventDefault();
        const formData = {
            symbol: document.getElementById('stockSymbol').value,
            quantity: document.getElementById('quantity').value,
            purchasePrice: document.getElementById('purchasePrice').value,
            purchaseDate: document.getElementById('purchaseDate').value
        };
        addNewStock(formData);
        modal.style.display = 'none';
        this.reset();
    };

    // Holdings Table Sorting
    document.querySelectorAll('.holdings-table th').forEach(header => {
        header.addEventListener('click', () => {
            const column = header.textContent.trim();
            sortHoldings(column);
        });
    });
}

// Helper Functions
function generateDateLabels(days) {
    const labels = [];
    const today = new Date();
    for (let i = days; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
    return labels;
}

function generatePerformanceData(days) {
    const data = [];
    let value = 1500000;
    for (let i = 0; i <= days; i++) {
        value *= (1 + (Math.random() * 0.02 - 0.01));
        data.push(value);
    }
    return data;
}

function updateHoldingsTable(holdings) {
    const tableBody = document.getElementById('holdingsTableBody');
    tableBody.innerHTML = holdings.map(stock => `
        <tr>
            <td>${stock.symbol}</td>
            <td>${stock.quantity}</td>
            <td>₹${stock.purchase_price.toFixed(2)}</td>
            <td>₹${stock.ltp.toFixed(2)}</td>
            <td>₹${stock.current_value.toLocaleString()}</td>
            <td class="${stock.pnl >= 0 ? 'profit' : 'loss'}">
                ₹${Math.abs(stock.pnl).toLocaleString()}
            </td>
            <td class="${stock.net_returns >= 0 ? 'profit' : 'loss'}">
                ${stock.net_returns.toFixed(2)}%
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn-edit" 
                        data-stock-id="${stock.id}"
                        data-symbol="${stock.symbol}"
                        data-quantity="${stock.quantity}"
                        data-price="${stock.purchase_price}"
                        data-date="${stock.purchase_date}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" data-stock-id="${stock.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    // Add event listeners after updating table
    addStockEventListeners();
}

function addStockEventListeners() {
    // Edit button listeners
    document.querySelectorAll('.btn-edit').forEach(button => {
        button.addEventListener('click', async function() {
            const stockId = this.getAttribute('data-stock-id');
            try {
                const response = await fetch(`/stock/get_stock/${stockId}/`);
                const data = await response.json();
                
                if (data.success) {
                    // Populate edit modal
                    document.getElementById('editStockId').value = stockId;
                    document.getElementById('editSymbol').value = data.stock.symbol;
                    document.getElementById('editQuantity').value = data.stock.quantity;
                    document.getElementById('editPrice').value = data.stock.purchase_price;
                    document.getElementById('editDate').value = data.stock.purchase_date;
                    
                    // Show modal
                    document.getElementById('editModal').style.display = 'block';
                } else {
                    alert(data.error || 'Error loading stock data');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Error loading stock data');
            }
        });
    });

    // Delete button listeners
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', async function() {
            const stockId = this.getAttribute('data-stock-id');
            if (confirm('Are you sure you want to delete this stock?')) {
                try {
                    const response = await fetch(`/stock/delete_stock/${stockId}/`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                        }
                    });

                    if (response.ok) {
                        window.location.reload();
                    } else {
                        const data = await response.json();
                        alert(data.error || 'Error deleting stock');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error deleting stock');
                }
            }
        });
    });
}

// Live Updates
function startLiveUpdates() {
    setInterval(() => {
        updateStockPrices();
        updatePortfolioMetrics();
    }, 5000);
}

function updateStockPrices() {
    document.querySelectorAll('.holdings-table tbody tr').forEach(async row => {
        const symbolCell = row.querySelector('.stock-symbol');
        if (!symbolCell) return;

        const symbol = symbolCell.textContent.trim();
        const priceCell = row.querySelector('.current-price');
        const valueCell = row.querySelector('.current-value');
        const pnlCell = row.querySelector('.pnl');
        const returnsCell = row.querySelector('.returns');

        try {
            const response = await fetch(`/stock/get_price/${symbol}/`);
            const data = await response.json();

            if (data.success) {
                const currentPrice = parseFloat(data.price);
                const quantity = parseInt(row.querySelector('.stock-quantity').textContent);
                const purchasePrice = parseFloat(row.querySelector('.purchase-price').textContent.replace('₹', ''));

                // Update price
                priceCell.textContent = `₹${currentPrice.toFixed(2)}`;
                
                // Update current value
                const currentValue = currentPrice * quantity;
                valueCell.textContent = `₹${currentValue.toFixed(2)}`;

                // Update P&L
                const pnl = (currentPrice - purchasePrice) * quantity;
                pnlCell.textContent = `${pnl >= 0 ? '+' : ''}₹${Math.abs(pnl).toFixed(2)}`;
                pnlCell.className = pnl >= 0 ? 'profit' : 'loss';

                // Update returns
                const returns = ((currentPrice - purchasePrice) / purchasePrice) * 100;
                returnsCell.textContent = `${returns >= 0 ? '+' : ''}${returns.toFixed(2)}%`;
                returnsCell.className = returns >= 0 ? 'profit' : 'loss';

            } else {
                // If error, keep existing price but show warning
                priceCell.classList.add('stale-price');
                priceCell.title = data.error || 'Unable to fetch current price';
            }
        } catch (error) {
            console.warn(`Failed to update price for ${symbol}:`, error);
            priceCell.classList.add('stale-price');
            priceCell.title = 'Unable to fetch current price';
        }
    });
}

// Add CSS for stale prices
const style = document.createElement('style');
style.textContent = `
    .stale-price {
        color: #ffa500;
        font-style: italic;
    }
    .stale-price::after {
        content: " (delayed)";
        font-size: 0.8em;
        color: #ff6b6b;
    }
`;
document.head.appendChild(style);

// Start price updates with error handling
function startPriceUpdates() {
    try {
        updateStockPrices();
        const updateInterval = setInterval(updateStockPrices, 5000);
        
        // Cleanup on page unload
        window.addEventListener('unload', () => {
            clearInterval(updateInterval);
        });
    } catch (error) {
        console.error('Error starting price updates:', error);
    }
}

// Initialize price updates when document loads
document.addEventListener('DOMContentLoaded', startPriceUpdates);

function initializeBenchmarkChart() {
    const ctx = document.getElementById('benchmarkChart');
    
    if (!ctx) {
        console.error('Benchmark chart canvas not found');
        return;
    }

    try {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [
                    {
                        label: 'Portfolio',
                        data: [65, 67, 70, 68, 72, 75, 73, 78, 80, 82, 85, 88],
                        borderColor: '#4a90e2',
                        tension: 0.4,
                        fill: false
                    },
                    {
                        label: 'NIFTY 50',
                        data: [60, 62, 65, 63, 68, 70, 69, 73, 75, 76, 78, 80],
                        borderColor: '#22c55e',
                        tension: 0.4,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#8a8aa0',
                            font: {
                                size: 12
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#8a8aa0',
                            font: {
                                size: 11
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#8a8aa0',
                            font: {
                                size: 11
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error initializing benchmark chart:', error);
    }
}

// Portfolio Performance Chart
function initializePortfolioChart() {
    const ctx = document.getElementById('portfolioChart').getContext('2d');
    if (!ctx) {
        console.error('Portfolio chart canvas not found');
        return;
    }

    const gradientFill = ctx.createLinearGradient(0, 0, 0, 400);
    gradientFill.addColorStop(0, 'rgba(75, 192, 192, 0.4)');
    gradientFill.addColorStop(1, 'rgba(75, 192, 192, 0.0)');

    let portfolioChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Portfolio Value',
                data: [],
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: gradientFill,
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            return `₹${context.parsed.y.toLocaleString('en-IN')}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(200, 200, 200, 0.1)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            }
        }
    });

    // Function to update chart data based on timeframe
    function updateChartData(timeframe) {
        const { labels, data } = generateTimeframeData(timeframe);
        portfolioChart.data.labels = labels;
        portfolioChart.data.datasets[0].data = data;
        portfolioChart.update();
    }

    // Generate data for different timeframes
    function generateTimeframeData(timeframe) {
        const now = new Date();
        const baseValue = 1545678;
        let points, volatility, labels = [], data = [];

        switch(timeframe) {
            case '1D':
                points = 24;
                volatility = 0.002;
                for(let i = 0; i < points; i++) {
                    labels.push(new Date(now.getTime() - (23-i) * 3600000).toLocaleTimeString('en-IN', {
                        hour: '2-digit',
                        minute: '2-digit'
                    }));
                }
                break;
            case '1W':
                points = 7;
                volatility = 0.005;
                for(let i = 0; i < points; i++) {
                    labels.push(new Date(now.getTime() - (6-i) * 86400000).toLocaleDateString('en-IN', {
                        weekday: 'short'
                    }));
                }
                break;
            case '1M':
                points = 30;
                volatility = 0.008;
                for(let i = 0; i < points; i++) {
                    labels.push(new Date(now.getTime() - (29-i) * 86400000).toLocaleDateString('en-IN', {
                        day: 'numeric'
                    }));
                }
                break;
            case '3M':
                points = 90;
                volatility = 0.01;
                for(let i = 0; i < points; i += 3) {
                    labels.push(new Date(now.getTime() - (89-i) * 86400000).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric'
                    }));
                }
                break;
            case '1Y':
                points = 12;
                volatility = 0.015;
                for(let i = 0; i < points; i++) {
                    labels.push(new Date(now.getFullYear(), now.getMonth() - (11-i), 1).toLocaleDateString('en-IN', {
                        month: 'short'
                    }));
                }
                break;
            case 'ALL':
                points = 24;
                volatility = 0.02;
                for(let i = 0; i < points; i++) {
                    labels.push(new Date(now.getFullYear() - 2 + Math.floor(i/12), i%12, 1).toLocaleDateString('en-IN', {
                        month: 'short',
                        year: '2-digit'
                    }));
                }
                break;
            default:
                points = 24;
                volatility = 0.002;
        }

        // Generate price data with trend
        let value = baseValue;
        let trend = Math.random() * 0.4 - 0.2; // Random trend between -0.2 and 0.2
        for(let i = 0; i < points; i++) {
            const noise = (Math.random() - 0.5) * 2 * volatility;
            value *= (1 + trend * volatility + noise);
            data.push(Math.round(value));
        }

        return { labels, data };
    }

    // Add click handlers for time filters
    document.querySelectorAll('.time-filter').forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            document.querySelectorAll('.time-filter').forEach(btn => {
                btn.classList.remove('active');
            });
            // Add active class to clicked button
            this.classList.add('active');
            // Update chart with new timeframe data
            updateChartData(this.textContent);
        });
    });

    // Initialize with 1D data
    updateChartData('1D');
}

// Initialize chart when DOM is loaded
document.addEventListener('DOMContentLoaded', initializePortfolioChart);

document.getElementById('addStockForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const stockData = {
        symbol: document.getElementById('stockSymbol').value,
        quantity: document.getElementById('quantity').value,
        purchase_price: document.getElementById('purchasePrice').value,
        purchase_date: document.getElementById('purchaseDate').value,
    };

    fetch('/add_stock/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        },
        body: JSON.stringify(stockData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close the modal and refresh the portfolio
            closeModal();
            loadPortfolio();
        } else {
            alert('Error adding stock');
        }
    });
});

function closeModal() {
    document.getElementById('addStockModal').style.display = 'none';
}

function loadPortfolio() {
    // Fetch and display the updated portfolio
    fetch('/portfolio_data/')
    .then(response => response.json())
    .then(data => {
        // Update the portfolio table with new data
        const holdingsTableBody = document.getElementById('holdingsTableBody');
        holdingsTableBody.innerHTML = '';
        data.holdings.forEach(stock => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${stock.symbol}</td>
                <td>${stock.quantity}</td>
                <td>${stock.purchase_price}</td>
                <td>${stock.ltp}</td>
                <td>${stock.current_value}</td>
                <td>${stock.pnl}</td>
                <td>${stock.net_returns}</td>
                <td><button class="btn-delete" data-id="${stock.id}">Delete</button></td>
            `;
            holdingsTableBody.appendChild(row);
        });
    });
}

// Get modal elements
const modal = document.getElementById('addStockModal');
const addStockBtn = document.getElementById('addStockBtn');
const closeBtn = document.querySelector('.close');
const addStockForm = document.getElementById('addStockForm');

// Show modal when Add Stock button is clicked
addStockBtn.addEventListener('click', () => {
    modal.style.display = 'block';
});

// Close modal when X is clicked
closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// Handle form submission
addStockForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('symbol', document.getElementById('stockSymbol').value.toUpperCase());
    formData.append('quantity', document.getElementById('quantity').value);
    formData.append('purchase_price', document.getElementById('purchasePrice').value);
    formData.append('purchase_date', document.getElementById('purchaseDate').value);
    formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);

    try {
        const response = await fetch('/stock/add_stock/', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            modal.style.display = 'none';
            addStockForm.reset();
            window.location.reload(); // Reload the page to show updated holdings
        } else {
            const data = await response.json();
            alert('Error adding stock: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error adding stock. Please try again.');
    }
});

// Function to delete stock
async function deleteStock(stockId) {
    if (confirm('Are you sure you want to delete this stock?')) {
        try {
            const response = await fetch(`/stock/delete_stock/${stockId}/`, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                }
            });

            if (response.ok) {
                window.location.reload();
            } else {
                alert('Error deleting stock');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error deleting stock');
        }
    }
}

// AI Recommendations functionality
async function updatePortfolioAnalysis() {
    const sectorContainer = document.getElementById('sectorDistribution');
    const recommendationsContainer = document.querySelector('.ai-recommendations-grid');
    
    // Show loading state
    if (sectorContainer) {
        sectorContainer.innerHTML = `
            <div class="loading">
                <i class="fas fa-spinner fa-spin"></i>
                <span>Loading sector distribution...</span>
            </div>
        `;
    }
    
    if (recommendationsContainer) {
        recommendationsContainer.innerHTML = `
            <div class="loading">
                <i class="fas fa-spinner fa-spin"></i>
                <span>Loading AI recommendations...</span>
            </div>
        `;
    }

    try {
        const response = await fetch('/stock/portfolio_analysis/', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            },
            credentials: 'same-origin'
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        
        if (data.success) {
            if (sectorContainer) {
                updateSectorDistribution(data.sector_distribution);
            }
            if (recommendationsContainer) {
                updateAIRecommendations(data.recommendations);
            }
        } else {
            throw new Error(data.error || 'Failed to load portfolio analysis');
        }
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Unable to load portfolio analysis');
    }
}

function updateAIRecommendations(recommendations) {
    const recommendationsGrid = document.querySelector('.recommendations-grid');
    if (!recommendationsGrid) return;

    const recommendationsHTML = recommendations.map(rec => `
        <div class="ai-recommendation-card ${rec.action.toLowerCase()}">
            <div class="rec-header">
                <div class="rec-symbol">
                    <h4>${rec.symbol}</h4>
                    <span class="sentiment ${rec.market_sentiment.direction.toLowerCase()}">
                        ${rec.market_sentiment.strength} ${rec.market_sentiment.direction}
                    </span>
                </div>
                <div class="rec-action ${rec.action.toLowerCase()}">${rec.action}</div>
            </div>
            
            <div class="rec-details">
                <div class="rec-price">
                    <span class="label">Current Price:</span>
                    <span class="value">₹${rec.current_price.toLocaleString()}</span>
                </div>
                <div class="rec-changes">
                    <div class="change-item">
                        <span class="label">5D Change:</span>
                        <span class="value ${rec.price_change_5d >= 0 ? 'positive' : 'negative'}">
                            ${rec.price_change_5d >= 0 ? '+' : ''}${rec.price_change_5d}%
                        </span>
                    </div>
                    <div class="change-item">
                        <span class="label">20D Change:</span>
                        <span class="value ${rec.price_change_20d >= 0 ? 'positive' : 'negative'}">
                            ${rec.price_change_20d >= 0 ? '+' : ''}${rec.price_change_20d}%
                        </span>
                    </div>
                </div>
            </div>

            <div class="technical-indicators">
                <div class="indicator">
                    <span class="label">RSI</span>
                    <span class="value ${rec.technical_indicators.rsi < 30 ? 'oversold' : rec.technical_indicators.rsi > 70 ? 'overbought' : 'neutral'}">
                        ${rec.technical_indicators.rsi}
                    </span>
                </div>
                <div class="indicator">
                    <span class="label">Volume Trend</span>
                    <span class="value ${rec.technical_indicators.volume_trend > 0 ? 'positive' : 'negative'}">
                        ${rec.technical_indicators.volume_trend}%
                    </span>
                </div>
            </div>

            <div class="rec-confidence">
                <div class="confidence-bar" style="width: ${rec.confidence}%"></div>
                <span>AI Confidence: ${rec.confidence}%</span>
            </div>

            <div class="rec-reasoning">
                <p><i class="fas fa-robot"></i> ${rec.reasoning}</p>
            </div>

            ${rec.action !== 'HOLD' ? `
                <div class="rec-action-suggestion">
                    <button class="btn-action ${rec.action.toLowerCase()}" onclick="actOnRecommendation('${rec.symbol}', '${rec.action}', ${rec.suggested_quantity}, ${rec.current_price})">
                        ${rec.action === 'BUY' ? 'Buy' : 'Sell'} ${rec.suggested_quantity} shares
                    </button>
                </div>
            ` : ''}
        </div>
    `).join('');

    recommendationsGrid.innerHTML = recommendationsHTML;
}

function updateSectorDistribution(sectorData) {
    const sectorContainer = document.getElementById('sectorDistribution');
    if (!sectorContainer) return;

    if (!sectorData.distribution || Object.keys(sectorData.distribution).length === 0) {
        sectorContainer.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <span>No sector data available</span>
            </div>
        `;
        return;
    }

    const sectors = Object.entries(sectorData.distribution);
    const sectorBars = sectors.map(([sector, percentage]) => `
        <div class="sector-bar" style="width: ${percentage}%;">
            <div class="sector-label">${sector}</div>
            <div class="sector-percentage">${percentage}%</div>
        </div>
    `).join('');

    sectorContainer.innerHTML = `
        <h3>Sector Distribution (Total Value: ₹${sectorData.total_value.toLocaleString()})</h3>
        <div class="sector-bars">
            ${sectorBars}
        </div>
    `;
}

function showError(message) {
    const containers = [
        document.querySelector('.sector-distribution'),
        document.querySelector('.ai-recommendations-grid')
    ];

    containers.forEach(container => {
        if (container) {
            container.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${message}</span>
                </div>
            `;
        }
    });
}

// Add error logging
window.onerror = function(msg, url, lineNo, columnNo, error) {
    console.error('Error: ' + msg + '\nURL: ' + url + '\nLine: ' + lineNo + '\nColumn: ' + columnNo + '\nError object: ' + JSON.stringify(error));
    return false;
};

// AI Assistant functionality
function initializeAIAssistant() {
    const assistant = document.getElementById('aiAssistant');
    const minimizeBtn = document.getElementById('minimizeAssistant');
    const chatMessages = document.getElementById('chatMessages');
    const userInput = document.getElementById('userMessage');
    const sendBtn = document.getElementById('sendMessage');
    const suggestionsContainer = document.createElement('div');
    suggestionsContainer.className = 'chat-suggestions';

    // Add suggestions container to the chat
    assistant.querySelector('.ai-assistant-body').insertBefore(
        suggestionsContainer, 
        assistant.querySelector('.chat-input')
    );

    // Initial suggestions
    const initialSuggestions = [
        "Portfolio overview",
        "Best performing stock",
        "Investment strategies",
        "Market trends"
    ];
    updateSuggestions(initialSuggestions);

    minimizeBtn.addEventListener('click', () => {
        assistant.classList.toggle('minimized');
        if (!assistant.classList.contains('minimized')) {
            userInput.focus();
        }
    });

    async function sendMessage(message) {
        try {
            // Add user message to chat
            addMessage('user', message);
            
            // Clear suggestions while waiting for response
            updateSuggestions([]);

            // Show typing indicator
            const typingIndicator = addTypingIndicator();

            const response = await fetch('/stock/ai_assistant/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                },
                body: JSON.stringify({ message: message })
            });

            const data = await response.json();
            
            // Remove typing indicator
            typingIndicator.remove();

            if (data.error) {
                addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
                updateSuggestions(initialSuggestions);
            } else {
                // Format the response with markdown-like syntax
                const formattedResponse = formatResponse(data.response);
                addMessage('assistant', formattedResponse);
                
                // Generate new suggestions based on the response
                generateSuggestions(data.response);
            }

        } catch (error) {
            console.error('Error:', error);
            addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
            updateSuggestions(initialSuggestions);
        }
    }

    function formatResponse(text) {
        // Convert markdown-like syntax to HTML
        return text
            .replace(/\\(.?)\\*/g, '<strong>$1</strong>')
            .replace(/\n\n/g, '<br><br>')
            .replace(/\n/g, '<br>')
            .replace(/📊/g, '<i class="fas fa-chart-bar"></i>')
            .replace(/💡/g, '<i class="fas fa-lightbulb"></i>')
            .replace(/💰/g, '<i class="fas fa-money-bill-wave"></i>')
            .replace(/🛡️/g, '<i class="fas fa-shield-alt"></i>');
    }

    function addMessage(type, content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message ${type}';
        messageDiv.innerHTML = `
            <div class="message-content">${content}</div>
            <div class="message-time">${new Date().toLocaleTimeString()}</div>
        `;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function addTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'message assistant typing';
        indicator.innerHTML = `
            <div class="typing-indicator">
                <span></span><span></span><span></span>
            </div>
        `;
        chatMessages.appendChild(indicator);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return indicator;
    }

    function updateSuggestions(suggestions) {
        suggestionsContainer.innerHTML = '';
        suggestions.forEach(suggestion => {
            const suggestionBtn = document.createElement('button');
            suggestionBtn.className = 'suggestion-btn';
            suggestionBtn.textContent = suggestion;
            suggestionBtn.addEventListener('click', () => {
                userInput.value = suggestion;
                sendMessage(suggestion);
            });
            suggestionsContainer.appendChild(suggestionBtn);
        });
    }

    function generateSuggestions(response) {
        const newSuggestions = [];
        if (response.includes('portfolio')) {
            newSuggestions.push("Portfolio overview");
        }
        if (response.includes('best performing')) {
            newSuggestions.push("Best performing stock");
        }
        if (response.includes('strategy')) {
            newSuggestions.push("Investment strategies");
        }
        if (response.includes('market')) {
            newSuggestions.push("Market trends");
        }
        updateSuggestions(newSuggestions);
    }

    sendBtn.addEventListener('click', () => {
        const message = userInput.value.trim();
        if (message) {
            sendMessage(message);
            userInput.value = '';
        }
    });

    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const message = userInput.value.trim();
            if (message) {
                sendMessage(message);
                userInput.value = '';
            }
        }
    });
}

// Initialize AI Assistant when document loads
document.addEventListener('DOMContentLoaded', function() {
    initializeAIAssistant();
});

document.addEventListener("DOMContentLoaded", function () {
    // Edit stock modal handling
    const editModal = document.getElementById("editModal");
    const editStockForm = document.getElementById("editStockForm");
    const editStockId = document.getElementById("editStockId");
    const editSymbol = document.getElementById("editSymbol");
    const editQuantity = document.getElementById("editQuantity");
    const editPrice = document.getElementById("editPrice");
    const editDate = document.getElementById("editDate");
    const holdingsTableBody = document.getElementById("holdingsTableBody");
    
    document.querySelectorAll(".btn-edit").forEach(button => {
        button.addEventListener("click", function () {
            editStockId.value = this.dataset.stockId;
            editSymbol.value = this.dataset.symbol;
            editQuantity.value = this.dataset.quantity;
            editPrice.value = this.dataset.price;
            editDate.value = this.dataset.date;
            editModal.style.display = "block";
        });
    });

    // Close modal
    document.querySelectorAll(".close").forEach(closeBtn => {
        closeBtn.addEventListener("click", function () {
            editModal.style.display = "none";
        });
    });

    // Handle stock update
    editStockForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const stockId = editStockId.value;
        const updatedData = {
            quantity: editQuantity.value,
            purchase_price: editPrice.value,
            purchase_date: editDate.value,
        };
        
        fetch(`/update-stock/${stockId}/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value
            },
            body: JSON.stringify(updatedData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector(`tr[data-stock-id='${stockId}']`).innerHTML = `
                    <td>${editSymbol.value}</td>
                    <td>${editQuantity.value}</td>
                    <td>₹${parseFloat(editPrice.value).toFixed(2)}</td>
                    <td>₹${parseFloat(data.current_price).toFixed(2)}</td>
                    <td>₹${(editQuantity.value * data.current_price).toFixed(2)}</td>
                    <td class="profit">+₹${data.pnl.toFixed(2)}</td>
                    <td class="profit">${data.returns.toFixed(2)}%</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-edit" data-stock-id="${stockId}" data-symbol="${editSymbol.value}" data-quantity="${editQuantity.value}" data-price="${editPrice.value}" data-date="${editDate.value}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-delete" data-stock-id="${stockId}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>`;
                editModal.style.display = "none";
            } else {
                alert("Failed to update stock.");
            }
        });
    });

    // Delete stock handling
    document.querySelectorAll(".btn-delete").forEach(button => {
        button.addEventListener("click", function () {
            const stockId = this.dataset.stockId;
            if (confirm("Are you sure you want to delete this stock?")) {
                fetch(`/delete-stock/${stockId}/`, {
                    method: "POST",
                    headers: {
                        "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector(`tr[data-stock-id='${stockId}']`).remove();
                    } else {
                        alert("Failed to delete stock.");
                    }
                });
            }
        });
    });
});

// Update the delete stock handler
document.querySelectorAll(".btn-delete").forEach(button => {
    button.addEventListener("click", function() {
        const stockId = this.dataset.stockId;
        if (confirm("Are you sure you want to delete this stock?")) {
            fetch(`/stock/get_stock/${stockId}/`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector("[name=csrfmiddlewaretoken]").value
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove the row from DOM
                    const row = this.closest('tr');
                    if (row) {
                        row.remove();
                    }
                } else {
                    alert(data.error || "Failed to delete stock.");
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("Error deleting stock. Please try again.");
            });
        }
    });
});

// Update the edit form submission handler
editStockForm.addEventListener("submit", function(e) {
    e.preventDefault();
    const stockId = editStockId.value;
    const updatedData = {
        quantity: editQuantity.value,
        purchase_price: editPrice.value,
        purchase_date: editDate.value,
        action: 'update'  // Add action identifier
    };
    
    fetch(`/stock/get_stock/${stockId}/`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value
        },
        body: JSON.stringify(updatedData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update the row without page refresh
            const row = document.querySelector(`tr[data-stock-id='${stockId}']`);
            if (row) {
                row.innerHTML = `
                    <td>${editSymbol.value}</td>
                    <td>${editQuantity.value}</td>
                    <td>₹${parseFloat(editPrice.value).toFixed(2)}</td>
                    <td>₹${parseFloat(data.current_price).toFixed(2)}</td>
                    <td>₹${(editQuantity.value * data.current_price).toFixed(2)}</td>
                    <td class="${data.pnl >= 0 ? 'profit' : 'loss'}">
                        ${data.pnl >= 0 ? '+' : ''}₹${Math.abs(data.pnl).toFixed(2)}
                    </td>
                    <td class="${data.returns >= 0 ? 'profit' : 'loss'}">
                        ${data.returns >= 0 ? '+' : ''}${data.returns.toFixed(2)}%
                    </td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-edit" 
                                data-stock-id="${stockId}"
                                data-symbol="${editSymbol.value}"
                                data-quantity="${editQuantity.value}"
                                data-price="${editPrice.value}"
                                data-date="${editDate.value}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-delete" data-stock-id="${stockId}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>`;
                
                // Reattach event listeners to the new buttons
                attachButtonEventListeners(row);
            }
            editModal.style.display = "none";
        } else {
            alert(data.error || "Failed to update stock.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("Error updating stock. Please try again.");
    });
});

// Helper function to attach event listeners to buttons
function attachButtonEventListeners(row) {
    const editBtn = row.querySelector('.btn-edit');
    const deleteBtn = row.querySelector('.btn-delete');

    if (editBtn) {
        editBtn.addEventListener('click', function() {
            editStockId.value = this.dataset.stockId;
            editSymbol.value = this.dataset.symbol;
            editQuantity.value = this.dataset.quantity;
            editPrice.value = this.dataset.price;
            editDate.value = this.dataset.date;
            editModal.style.display = "block";
        });
    }

    if (deleteBtn) {
        deleteBtn.addEventListener('click', function() {
            const stockId = this.dataset.stockId;
            if (confirm("Are you sure you want to delete this stock?")) {
                fetch(`/stock/get_stock/${stockId}/`, {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': document.querySelector("[name=csrfmiddlewaretoken]").value
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        row.remove();
                    } else {
                        alert(data.error || "Failed to delete stock.");
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("Error deleting stock. Please try again.");
                });
            }
        });
    }
}

// Edit form submission handler
document.getElementById('editStockForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const stockId = document.getElementById('editStockId').value;
    
    const formData = {
        action: 'update',
        quantity: document.getElementById('editQuantity').value,
        purchase_price: document.getElementById('editPrice').value,
        purchase_date: document.getElementById('editDate').value
    };

    try {
        const response = await fetch(`/stock/get_stock/${stockId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            },
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (data.success) {
            const row = document.querySelector(`tr[data-stock-id="${stockId}"]`);
            if (row) {
                // Update row cells with new values
                row.querySelector('.stock-quantity').textContent = formData.quantity;
                row.querySelector('.purchase-price').textContent = `₹${parseFloat(formData.purchase_price).toFixed(2)}`;
                row.querySelector('.current-price').textContent = `₹${parseFloat(data.current_price).toFixed(2)}`;
                row.querySelector('.current-value').textContent = `₹${(data.current_price * formData.quantity).toFixed(2)}`;
                
                // Update P&L and returns
                const pnlCell = row.querySelector('.pnl');
                const returnsCell = row.querySelector('.returns');
                
                pnlCell.textContent = data.pnl.toFixed(2);
                pnlCell.className = `pnl ${data.pnl >= 0 ? 'profit' : 'loss'}`;
                
                returnsCell.textContent = `${data.returns.toFixed(2)}%`;
                returnsCell.className = `returns ${data.returns >= 0 ? 'profit' : 'loss'}`;
            }
            
            // Close modal
            document.getElementById('editModal').classList.remove('show');
            
            // Show success message
            alert('Stock updated successfully');
        } else {
            throw new Error(data.error || 'Failed to update stock');
        }
    } catch (error) {
        console.error('Error:', error);
        alert(error.message || 'Error updating stock. Please try again.');
    }
});

// Delete button handler
document.addEventListener('click', async function(e) {
    const deleteBtn = e.target.closest('.btn-delete');
    if (!deleteBtn) return;

    e.preventDefault();
    
    const stockId = deleteBtn.dataset.stockId;
    if (!stockId || !confirm('Are you sure you want to delete this stock?')) return;

    try {
        const response = await fetch(`/stock/get_stock/${stockId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            },
            body: JSON.stringify({ action: 'delete' })
        });

        const data = await response.json();

        if (data.success) {
            // Remove the row
            const row = deleteBtn.closest('tr');
            row.remove();

            // Check if table is empty
            const tbody = document.getElementById('holdingsTableBody');
            if (tbody.children.length === 0) {
                tbody.innerHTML = `
                    <tr id="no-stocks-row">
                        <td colspan="8" class="text-center">No stocks in your portfolio. Add some stocks to get started!</td>
                    </tr>`;
            }

            alert('Stock deleted successfully');
        } else {
            throw new Error(data.error || 'Failed to delete stock');
        }
    } catch (error) {
        console.error('Error:', error);
        alert(error.message || 'Error deleting stock. Please try again.');
    }
});

// Function to update stock prices periodically
function startPriceUpdates() {
    setInterval(async () => {
        const rows = document.querySelectorAll('tr[data-stock-id]');
        for (const row of rows) {
            const stockId = row.dataset.stockId;
            const symbol = row.querySelector('.stock-symbol').textContent;
            
            try {
                const response = await fetch(`/stock/get_price/${symbol}/`);
                const data = await response.json();
                
                if (data.success) {
                    const currentPrice = parseFloat(data.price);
                    const quantity = parseInt(row.querySelector('.stock-quantity').textContent);
                    const purchasePrice = parseFloat(row.querySelector('.purchase-price').textContent.replace('₹', ''));
                    
                    // Update current price and calculations
                    row.querySelector('.current-price').textContent = `₹${currentPrice.toFixed(2)}`;
                    row.querySelector('.current-value').textContent = `₹${(currentPrice * quantity).toFixed(2)}`;
                    
                    const pnl = (currentPrice - purchasePrice) * quantity;
                    const returns = ((currentPrice - purchasePrice) / purchasePrice) * 100;
                    
                    const pnlCell = row.querySelector('.pnl');
                    const returnsCell = row.querySelector('.returns');
                    
                    pnlCell.textContent = pnl.toFixed(2);
                    pnlCell.className = `pnl ${pnl >= 0 ? 'profit' : 'loss'}`;
                    
                    returnsCell.textContent = `${returns.toFixed(2)}%`;
                    returnsCell.className = `returns ${returns >= 0 ? 'profit' : 'loss'}`;
                }
            } catch (error) {
                console.error(`Error updating price for ${symbol}:`, error);
            }
        }
    }, 5000); // Update every 5 seconds
}

// Start price updates when document loads
document.addEventListener('DOMContentLoaded', startPriceUpdates);

// Remove any existing delete handlers
const existingHandlers = document.querySelectorAll('.btn-delete').forEach(btn => {
    const oldHandler = btn.onclick;
    if (oldHandler) {
        btn.removeEventListener('click', oldHandler);
    }
});

// Single delete handler using event delegation
function handleDelete(e) {
    const deleteBtn = e.target.closest('.btn-delete');
    if (!deleteBtn) return;

    e.preventDefault();
    e.stopPropagation();
    
    const stockId = deleteBtn.getAttribute('data-stock-id');
    if (!stockId) return;

    // Single confirmation dialog
    if (confirm('Are you sure you want to delete this stock?')) {
        fetch(`/stock/get_stock/${stockId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            },
            body: JSON.stringify({ action: 'delete' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const row = deleteBtn.closest('tr');
                if (row) {
                    row.remove();
                }
            } else {
                throw new Error(data.error || 'Failed to delete stock');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error deleting stock. Please try again.');
        });
    }
}

// Add single event listener at document level
document.removeEventListener('click', handleDelete);
document.addEventListener('click', handleDelete);

// Initialize chat functionality
function initializeChat() {
    const chatWidget = document.querySelector('.ai-chat-widget');
    const chatMessages = document.getElementById('chatMessages');
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendMessage');
    const minimizeButton = document.getElementById('minimizeChat');

    // Add welcome message
    addMessage('ai', `👋 Welcome! I'm your AI Portfolio Assistant. I can help you with:

• 📊 Portfolio Analysis
• 💰 Investment Recommendations
• ⚠️ Risk Assessment
• 📈 Market Insights
• 📉 Performance Tracking

How can I assist you today?`);

    async function sendMessage(message) {
        if (!message.trim()) return;

        // Add user message
        addMessage('user', message);
        userInput.value = '';

        // Show typing indicator
        const typingIndicator = addTypingIndicator();

        try {
            const response = await fetch('/stock/ai_assistant/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                },
                body: JSON.stringify({ message: message })
            });

            const data = await response.json();
            
            // Remove typing indicator
            typingIndicator.remove();

            if (data.response) {
                addMessage('ai', data.response);
            } else {
                throw new Error('Invalid response from server');
            }

        } catch (error) {
            console.error('Chat Error:', error);
            addMessage('ai', 'Sorry, I encountered an error. Please try again.');
        }
    }

    function addMessage(type, content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;
        messageDiv.innerHTML = formatMessage(content);
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function formatMessage(text) {
        return text
            .replace(/\n/g, '<br>')
            .replace(/📊/g, '<i class="fas fa-chart-bar"></i>')
            .replace(/💰/g, '<i class="fas fa-money-bill-wave"></i>')
            .replace(/⚠️/g, '<i class="fas fa-exclamation-triangle"></i>')
            .replace(/📈/g, '<i class="fas fa-chart-line"></i>')
            .replace(/📉/g, '<i class="fas fa-chart-line fa-flip-vertical"></i>')
            .replace(/👋/g, '<i class="fas fa-hand-wave"></i>');
    }

    function addTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.innerHTML = '<span></span><span></span><span></span>';
        chatMessages.appendChild(indicator);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return indicator;
    }

    // Event Listeners
    sendButton.addEventListener('click', () => {
        sendMessage(userInput.value);
    });

    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage(userInput.value);
        }
    });

    minimizeButton.addEventListener('click', () => {
        chatWidget.classList.toggle('minimized');
    });

    // Handle suggestion buttons
    document.querySelectorAll('.suggestion-btn').forEach(button => {
        button.addEventListener('click', () => {
            sendMessage(button.dataset.query);
        });
    });
}

// Initialize chat when document is ready
document.addEventListener('DOMContentLoaded', initializeChat);

document.getElementById('editStockForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const stockId = document.getElementById('editStockId').value;
    const data = {
        stock_id: stockId,
        quantity: document.getElementById('editQuantity').value,
        purchase_price: document.getElementById('editPrice').value,
        purchase_date: document.getElementById('editDate').value,
    };

    fetch('/stock/update_stock/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update the table row with new values
            updateTableRow(stockId, data);
            // Close modal
            document.getElementById('editModal').style.display = 'none';
        } else {
            alert('Error updating stock: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating stock');
    });
});

function updateTableRow(stockId, data) {
    const row = document.querySelector(`tr[data-stock-id="${stockId}"]`);
    if (row) {
        row.querySelector('.stock-quantity').textContent = data.quantity;
        row.querySelector('.purchase-price').textContent = `₹${parseFloat(data.purchase_price).toFixed(2)}`;
        row.querySelector('.current-value').textContent = `₹${parseFloat(data.current_value).toFixed(2)}`;
        row.querySelector('.pnl').textContent = parseFloat(data.pnl).toFixed(2);
        row.querySelector('.returns').textContent = `${parseFloat(data.returns).toFixed(2)}%`;
        
        // Update PNL and returns classes
        const pnlCell = row.querySelector('.pnl');
        const returnsCell = row.querySelector('.returns');
        pnlCell.className = `pnl ${parseFloat(data.pnl) >= 0 ? 'profit' : 'loss'}`;
        returnsCell.className = `returns ${parseFloat(data.returns) >= 0 ? 'profit' : 'loss'}`;
    }
}

// Portfolio chart initialization
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('portfolioChart').getContext('2d');
    let portfolioChart = null;

    // Create gradient fill
    const gradientFill = ctx.createLinearGradient(0, 0, 0, 400);
    gradientFill.addColorStop(0, 'rgba(75, 192, 192, 0.4)');
    gradientFill.addColorStop(1, 'rgba(75, 192, 192, 0.0)');

    // Chart configuration
    const chartConfig = {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Portfolio Value',
                data: [],
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: gradientFill,
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            return `₹${context.parsed.y.toLocaleString('en-IN')}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(200, 200, 200, 0.1)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    };

    // Initialize chart
    portfolioChart = new Chart(ctx, chartConfig);

    // Generate data for different timeframes
    function generateChartData(timeframe) {
        const data = [];
        const labels = [];
        const now = new Date();
        const baseValue = 1545678; // Base portfolio value
        let points, interval, volatility;

        switch(timeframe) {
            case '1D':
                points = 24;
                volatility = 0.002;
                for(let i = 0; i < points; i++) {
                    const time = new Date(now.getTime() - (23-i) * 3600000);
                    labels.push(time.toLocaleTimeString('en-IN', {
                        hour: '2-digit',
                        minute: '2-digit'
                    }));
                }
                break;
            case '1W':
                points = 7;
                volatility = 0.005;
                for(let i = 0; i < points; i++) {
                    const date = new Date(now.getTime() - (6-i) * 86400000);
                    labels.push(date.toLocaleDateString('en-IN', {
                        weekday: 'short'
                    }));
                }
                break;
            case '1M':
                points = 30;
                volatility = 0.008;
                for(let i = 0; i < points; i++) {
                    const date = new Date(now.getTime() - (29-i) * 86400000);
                    labels.push(date.getDate());
                }
                break;
            case '3M':
                points = 90;
                volatility = 0.01;
                for(let i = 0; i < points; i++) {
                    const date = new Date(now.getTime() - (89-i) * 86400000);
                    if(i % 7 === 0) {
                        labels.push(date.toLocaleDateString('en-IN', {
                            month: 'short',
                            day: 'numeric'
                        }));
                    } else {
                        labels.push('');
                    }
                }
                break;
            case '1Y':
                points = 12;
                volatility = 0.015;
                for(let i = 0; i < points; i++) {
                    const date = new Date(now.getFullYear(), now.getMonth() - (11-i), 1);
                    labels.push(date.toLocaleDateString('en-IN', {
                        month: 'short'
                    }));
                }
                break;
            case 'ALL':
                points = 24;
                volatility = 0.02;
                for(let i = 0; i < points; i++) {
                    const date = new Date(now.getFullYear() - 2, i, 1);
                    labels.push(date.toLocaleDateString('en-IN', {
                        month: 'short',
                        year: '2-digit'
                    }));
                }
                break;
        }

        // Generate price data
        let currentValue = baseValue;
        for(let i = 0; i < points; i++) {
            const change = currentValue * volatility * (Math.random() - 0.5);
            currentValue += change;
            data.push(currentValue);
        }

        return { labels, data };
    }

    // Handle time filter clicks
    document.querySelectorAll('.time-filter').forEach(button => {
        button.addEventListener('click', function() {
            // Update active state
            document.querySelectorAll('.time-filter').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');

            // Get and update chart data
            const timeframe = this.textContent;
            const { labels, data } = generateChartData(timeframe);
            
            portfolioChart.data.labels = labels;
            portfolioChart.data.datasets[0].data = data;
            portfolioChart.update();
        });
    });

    // Initialize with 1D data
    const { labels, data } = generateChartData('1D');
    portfolioChart.data.labels = labels;
    portfolioChart.data.datasets[0].data = data;
    portfolioChart.update();
});

// Add this function to handle table sorting
function sortHoldingsTable(sortBy) {
    const tableBody = document.getElementById('holdingsTableBody');
    const rows = Array.from(tableBody.getElementsByTagName('tr'));
    
    // Skip if no rows or only "no stocks" row
    if (rows.length === 0 || (rows.length === 1 && rows[0].id === 'no-stocks-row')) {
        return;
    }

    rows.sort((a, b) => {
        try {
            switch (sortBy) {
                case 'alphabetical':
                    const symbolA = a.cells[0].textContent.trim();
                    const symbolB = b.cells[0].textContent.trim();
                    return symbolA.localeCompare(symbolB);
                    
                case 'value':
                    const valueA = parseFloat(a.cells[4].textContent.replace('₹', '').replace(/,/g, ''));
                    const valueB = parseFloat(b.cells[4].textContent.replace('₹', '').replace(/,/g, ''));
                    return valueB - valueA; // High to Low
                    
                case 'returns':
                    const returnsA = parseFloat(a.cells[6].textContent.replace('%', ''));
                    const returnsB = parseFloat(b.cells[6].textContent.replace('%', ''));
                    return valueB - valueA; // High to Low
                    
                default:
                    return 0;
            }
        } catch (error) {
            console.error('Sorting error:', error);
            return 0;
        }
    });

    // Clear and re-append sorted rows
    while (tableBody.firstChild) {
        tableBody.removeChild(tableBody.firstChild);
    }
    rows.forEach(row => tableBody.appendChild(row));
}

// Add event listener for sort select
document.addEventListener('DOMContentLoaded', function() {
    const sortSelect = document.getElementById('sortHoldings');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortHoldingsTable(this.value);
        });
    }

    // Add event listener for search
    const searchInput = document.getElementById('stockSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#holdingsTableBody tr');

            rows.forEach(row => {
                if (row.id === 'no-stocks-row') return;
                
                const symbol = row.cells[0].textContent.toLowerCase();
                row.style.display = symbol.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});