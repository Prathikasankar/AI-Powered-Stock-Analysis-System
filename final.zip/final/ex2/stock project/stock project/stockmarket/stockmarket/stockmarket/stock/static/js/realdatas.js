// Market symbols
const MARKET_SYMBOLS = {
    NIFTY50: 'NIFTY 50',
    SENSEX: 'SENSEX',
    BANKNIFTY: 'NIFTY BANK'
};

// API configuration
const API_CONFIG = {
    baseUrl: '/api/market',  // This will be handled by Django view
    headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]')?.value
    }
};

// Function to format numbers with commas and decimals
function formatNumber(num) {
    return new Intl.NumberFormat('en-IN', {
        maximumFractionDigits: 2,
        minimumFractionDigits: 2,
        style: 'currency',
        currency: 'INR'
    }).format(num);
}

// Function to format percentage changes
function formatChange(change, absolute) {
    const sign = change >= 0 ? '+' : '';
    return `${sign}${absolute.toFixed(2)} (${change.toFixed(2)}%)`;
}

// Function to update market overview cards
async function updateMarketOverview() {
    try {
        // Fetch current market data through Django view
        const response = await fetch(`${API_CONFIG.baseUrl}/indices`, {
            headers: API_CONFIG.headers,
            credentials: 'same-origin'
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        // Update NIFTY 50
        updateMarketCard(data.NIFTY50, 'nifty50-card');

        // Update timestamp
        updateLastUpdated(data.timestamp);

    } catch (error) {
        console.error('Error updating market overview:', error);
        showErrorMessage('Unable to fetch market data');
    }
}

// Function to update individual market card
function updateMarketCard(data, cardId) {
    const card = document.getElementById(cardId);
    if (!card || !data) return;

    const price = card.querySelector('.price');
    const change = card.querySelector('.change');
    const timestamp = card.querySelector('.timestamp');

    if (price) {
        const oldValue = parseFloat(price.dataset.value || 0);
        const newValue = data.lastPrice;
        price.dataset.value = newValue;
        price.textContent = formatNumber(newValue);
        price.classList.add(newValue > oldValue ? 'flash-up' : 'flash-down');
        setTimeout(() => price.classList.remove('flash-up', 'flash-down'), 1000);
    }

    if (change) {
        const changeValue = data.change;
        const changePercent = data.changePercent;
        change.textContent = formatChange(changePercent, changeValue);
        change.className = `change ${changeValue >= 0 ? 'up' : 'down'}`;
    }

    if (timestamp) {
        timestamp.textContent = new Date(data.timestamp).toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        });
    }

    // Update mini chart if available
    if (data.intraday) {
        updateMiniChart(card.querySelector('.chart-mini'), data.intraday);
    }
}

// Function to update mini charts
function updateMiniChart(container, data) {
    if (!container || !data) return;

    const ctx = container.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => d.time),
            datasets: [{
                data: data.map(d => d.price),
                borderColor: data[data.length - 1].price >= data[0].price ? '#22c55e' : '#ef4444',
                borderWidth: 1,
                fill: false,
                tension: 0.4,
                pointRadius: 0
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { x: { display: false }, y: { display: false } },
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Function to start real-time updates
function startLiveUpdates() {
    // Initial update
    updateMarketOverview();

    // Update every 1 second
    setInterval(updateMarketOverview, 1000);
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    startLiveUpdates();
});

// Error handling
function showErrorMessage(message) {
    const errorContainer = document.getElementById('error-container');
    if (errorContainer) {
        errorContainer.textContent = message;
        errorContainer.classList.add('visible');
        setTimeout(() => errorContainer.classList.remove('visible'), 5000);
    }
}