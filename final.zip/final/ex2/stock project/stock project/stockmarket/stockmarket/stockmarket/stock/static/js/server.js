const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());

// Expanded market data for more realistic dummy data
const marketData = {
    bse: {
        SENSEX: { base: 73500, range: 1000 },
        BANKEX: { base: 48000, range: 800 },
        IT: { base: 35000, range: 600 },
        AUTO: { base: 42000, range: 700 },
        FMCG: { base: 45000, range: 750 },
        METAL: { base: 25000, range: 500 },
        OIL: { base: 38000, range: 600 },
        POWER: { base: 28000, range: 450 },
        HEALTHCARE: { base: 32000, range: 550 },
        CONSUMER: { base: 41000, range: 650 }
    },
    nse: {
        NIFTY: { base: 22400, range: 400 },
        BANK: { base: 46500, range: 800 },
        IT: { base: 32500, range: 500 },
        AUTO: { base: 18900, range: 300 },
        FMCG: { base: 52000, range: 850 },
        METAL: { base: 8500, range: 200 },
        PHARMA: { base: 15000, range: 300 },
        REALTY: { base: 12000, range: 250 },
        MIDCAP: { base: 42000, range: 700 },
        SMALLCAP: { base: 11000, range: 200 }
    }
};

// Helper function to generate realistic dummy data
function generateDummyData(type, index) {
    const data = marketData[type][index.type] || marketData[type][type.toUpperCase()];
    const base = data?.base || (type === 'bse' ? 65000 : 22000);
    const range = data?.range || 500;

    const price = base + (Math.random() * range * 2 - range);
    const change = (Math.random() * range/10) * (Math.random() < 0.5 ? -1 : 1);
    const changePercent = (change / price) * 100;

    return {
        name: index.name,
        symbol: index.symbol,
        c: parseFloat(price.toFixed(2)),
        d: parseFloat(change.toFixed(2)),
        dp: parseFloat(changePercent.toFixed(2)),
        h: parseFloat((price + Math.abs(change)).toFixed(2)),
        l: parseFloat((price - Math.abs(change)).toFixed(2)),
        v: Math.floor(Math.random() * 10000000) + 1000000,
        type: type.toUpperCase()
    };
}

// Route to serve market data
app.get('/api/market-data', (req, res) => {
    try {
        // Generate data for both BSE and NSE indices
        const bseData = Object.keys(marketData.bse).map(key => ({
            type: key,
            name: `BSE ${key}`,
            symbol: `^BSE${key}`
        })).map(index => generateDummyData('bse', index));

        const nseData = Object.keys(marketData.nse).map(key => ({
            type: key,
            name: `NIFTY ${key}`,
            symbol: `^NSE${key}`
        })).map(index => generateDummyData('nse', index));

        const allData = [...bseData, ...nseData];

        res.json({
            status: 'success',
            timestamp: new Date().toISOString(),
            count: allData.length,
            data: allData
        });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            status: 'error',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));