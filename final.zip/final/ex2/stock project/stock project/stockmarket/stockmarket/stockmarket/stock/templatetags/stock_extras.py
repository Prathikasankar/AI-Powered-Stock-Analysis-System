from django import template
from decimal import Decimal

register = template.Library()

@register.filter
def calc_current_price(value):
    """Calculate current price with 5% markup"""
    return float(value) * 1.05

@register.filter
def calc_current_value(quantity, price):
    """Calculate current value"""
    return float(quantity) * float(price) * 1.05

@register.filter
def calc_pnl(quantity, price):
    """Calculate P&L"""
    return float(quantity) * float(price) * 0.05