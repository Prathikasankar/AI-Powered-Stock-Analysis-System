from django.urls import path, include
from . import views


app_name = 'stock'

urlpatterns = [
    path('', views.home, name='home'),
    path('indices/', views.indices, name='indices'),
    path('livestocks/', views.livestocks, name='livestocks'),
    path('features/', views.features, name='features'),
    path('portfolio/', views.portfolio, name='portfolio'),
    path('trending_stocks/', views.trending_stocks, name='trending_stocks'),
    path('login/', views.login, name='login'),
    path('register/', views.register, name='register'),
    path('user_logout/', views.user_logout, name='user_logout'),
    path('table/', views.table, name='table'),
    path('portfolio_data/', views.portfolio_data, name='portfolio_data'),
    path('stock/add_stock/', views.add_stock, name='add_stock'),
    path('stock/get_holdings/', views.get_holdings, name='get_holdings'),
    path('get_stock/<int:stock_id>/', views.get_stock, name='get_stock'),
    path('stock/get_stock/<int:stock_id>/', views.get_stock, name='get_stock'),
    path('stock/get_price/<str:symbol>/', views.get_stock_price, name='get_stock_price'),
    path('ai_recommendations/', views.ai_recommendations, name='ai_recommendations'),
    path('portfolio_analysis/', views.portfolio_analysis, name='portfolio_analysis'),
    path('stock/ai_assistant/', views.ai_assistant_response, name='ai_assistant'),
    path('stock/edit_stock/<int:stock_id>/', views.edit_stock, name='edit_stock'),
    path('stock/delete_stock/<int:stock_id>/', views.delete_stock, name='delete_stock'),
    path('update_stock/', views.update_stock, name='update_stock'),
]