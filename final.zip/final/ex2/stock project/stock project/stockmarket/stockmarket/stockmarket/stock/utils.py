import yfinance as yf
from decimal import Decimal
import logging
from django.core.cache import cache
from typing import Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)

def get_real_time_price(symbol: str) -> Optional[Decimal]:
    """
    Get real-time stock price with proper market detection
    """
    try:
        # Check cache first
        cache_key = f'stock_price_{symbol}'
        cached_price = cache.get(cache_key)
        if cached_price:
            return Decimal(str(cached_price))

        # Determine if it's a US stock or Indian stock
        ticker_symbol = symbol
        if '.' not in symbol:  # No market suffix
            # Try US market first
            us_ticker = yf.Ticker(symbol)
            us_info = us_ticker.info
            if us_info and 'regularMarketPrice' in us_info:
                price = Decimal(str(us_info['regularMarketPrice']))
                cache.set(cache_key, float(price), 60)
                return price
            
            # Try Indian market
            nse_symbol = f"{symbol}.NS"
            nse_ticker = yf.Ticker(nse_symbol)
            nse_info = nse_ticker.info
            if nse_info and 'regularMarketPrice' in nse_info:
                price = Decimal(str(nse_info['regularMarketPrice']))
                cache.set(cache_key, float(price), 60)
                return price
        else:
            # Symbol already has market suffix
            ticker = yf.Ticker(symbol)
            info = ticker.info
            if info and 'regularMarketPrice' in info:
                price = Decimal(str(info['regularMarketPrice']))
                cache.set(cache_key, float(price), 60)
                return price

        logger.warning(f"No price found for symbol: {symbol}")
        return None

    except requests.exceptions.RequestException as e:
        logger.error(f"Network error fetching price for {symbol}: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error fetching price for {symbol}: {str(e)}", exc_info=True)
        return None