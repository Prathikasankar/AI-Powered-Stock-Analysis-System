from django.shortcuts import redirect, render, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import User_register, Stock
from decimal import Decimal, InvalidOperation  # Added InvalidOperation
from django.core.exceptions import ValidationError
from django.views.decorators.http import require_POST
from django.core.exceptions import RequestAborted
import socket
import logging
from django.db.models import Prefetch
from django.views.decorators.cache import cache_page
from .utils import get_real_time_price
from django.contrib.auth.decorators import login_required
import yfinance as yf
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import random

logger = logging.getLogger(__name__)

# Add this import at the top of the file with other imports
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from datetime import datetime
from .models import Stock

# Create your views here.
def home(request):
    return render(request, 'index.html')

def indices(request):
    return render(request, 'indices.html')

def livestocks(request):
    return render(request, 'live-stocks.html')

def features(request):
    return render(request, 'features.html')

@cache_page(60)  # Cache the page for 1 minute
def portfolio(request):
    if 'user_id' not in request.session:
        messages.error(request, "Please login first")
        return redirect('stock:login')
    
    # Use select_related for better query performance
    stocks = Stock.objects.filter(
        user_id=request.session['user_id']
    ).select_related('user')
    
    return render(request, 'portfolio.html', {'stocks': stocks})

def trending_stocks(request):
    return render(request, 'trending stocks.html')

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        # Check if user exists
        user = User_register.objects.filter(email=email, password=password).first()
        
        if user:
            # Store user details in session
            request.session['user_id'] = user.id
            request.session['username'] = user.username
            messages.success(request, "Login successful!")
            return redirect('stock:portfolio')  # Redirect to portfolio page
        else:
            messages.error(request, "Invalid email or password!")
            return redirect('stock:login')
    
    return render(request, 'login.html')


def register(request):
    if request.method == 'POST':
        # Process the form data
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('stock:register')
        

        if User_register.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect('stock:register')
        
        if User_register.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return redirect('stock:register')
        
        user = User_register(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Registration successful!")
        return redirect('stock:login')
    return render(request, 'register.html')

def user_logout(request):
    request.session.flush()  # Clear session data
    messages.success(request, "You have been logged out.")
    return redirect("stock:login")

def table(request):
    return render(request, 'table.html')

@csrf_exempt
def add_stock(request):
    if 'user_id' not in request.session:
        messages.error(request, "Please login first")
        return redirect('stock:login')

    if request.method == 'POST':
        try:
            # Get form data
            data = request.POST
            if not data:
                # If POST data is empty, try to parse JSON data
                data = json.loads(request.body)
            
            symbol = data.get('symbol', '').upper()
            quantity = data.get('quantity')
            purchase_price = data.get('purchase_price')
            purchase_date = data.get('purchase_date')

            # Validate required fields
            if not all([symbol, quantity, purchase_price, purchase_date]):
                return JsonResponse({
                    'success': False,
                    'error': "All fields are required"
                })

            # Convert and validate numeric values
            try:
                quantity = int(quantity)
                purchase_price = Decimal(str(purchase_price))
                
                if quantity <= 0:
                    raise ValidationError("Quantity must be positive")
                if purchase_price <= 0:
                    raise ValidationError("Purchase price must be positive")
                
            except (ValueError, InvalidOperation):
                return JsonResponse({
                    'success': False,
                    'error': "Invalid quantity or price format"
                })

            # Try to get existing stock
            existing_stock = Stock.objects.filter(
                user_id=request.session['user_id'],
                symbol=symbol
            ).first()

            if existing_stock:
                # Update existing stock
                total_value = (existing_stock.quantity * existing_stock.purchase_price) + (quantity * purchase_price)
                new_quantity = existing_stock.quantity + quantity
                new_avg_price = total_value / Decimal(str(new_quantity))
                
                existing_stock.quantity = new_quantity
                existing_stock.purchase_price = new_avg_price
                existing_stock.save()
                
                return JsonResponse({
                    'success': True,
                    'message': f"Updated {symbol}: total quantity {new_quantity}"
                })
            else:
                # Create new stock
                stock = Stock.objects.create(
                    user_id=request.session['user_id'],
                    symbol=symbol,
                    quantity=quantity,
                    purchase_price=purchase_price,
                    purchase_date=purchase_date
                )
                
                return JsonResponse({
                    'success': True,
                    'message': f"Added {quantity} shares of {symbol}"
                })

        except ValidationError as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f"Error adding stock: {str(e)}"
            })

    return render(request, 'add_stock.html')

def portfolio_data(request):
    stocks = Stock.objects.filter(user=request.user)
    holdings = []
    for stock in stocks:
        holdings.append({
            'symbol': stock.symbol,
            'quantity': stock.quantity,
            'purchase_price': stock.purchase_price,
            'ltp': stock.get_ltp(),  # Assuming you have a method to get the latest price
            'current_value': stock.get_current_value(),  # Assuming you have a method to get the current value
            'pnl': stock.get_pnl(),  # Assuming you have a method to get the profit and loss
            'net_returns': stock.get_net_returns()  # Assuming you have a method to get the net returns
        })
    return JsonResponse({'holdings': holdings})

def get_holdings(request):
    if 'user_id' not in request.session:
        return JsonResponse({'success': False, 'error': 'Not logged in'})
    
    try:
        stocks = Stock.objects.filter(user_id=request.session['user_id'])
        holdings = []
        
        for stock in stocks:
            try:
                # Use fixed markup for demo purposes
                markup_percentage = Decimal('1.05')  # 5% markup
                ltp = stock.purchase_price * markup_percentage
                
                quantity = Decimal(str(stock.quantity))
                purchase_price = Decimal(str(stock.purchase_price))
                current_value = quantity * ltp
                pnl = current_value - (quantity * purchase_price)
                
                # Calculate returns (always positive for demo)
                net_returns = Decimal('5.00')  # Fixed 5% return

                holdings.append({
                    'id': stock.id,
                    'symbol': stock.symbol,
                    'quantity': int(quantity),
                    'purchase_price': float(purchase_price),
                    'ltp': float(ltp),
                    'current_value': float(current_value),
                    'pnl': float(pnl),
                    'net_returns': float(net_returns)
                })
            except Exception as e:
                continue

        return JsonResponse({
            'success': True,
            'holdings': holdings
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})




@csrf_exempt
def get_stock(request, stock_id):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Invalid request method'})

    try:
        stock = Stock.objects.get(id=stock_id)
        
        # Ensure we have valid JSON data
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'success': False, 'error': 'Invalid JSON data'}, status=400)

        action = data.get('action')

        if action == 'update':
            try:
                stock.quantity = int(data.get('quantity'))
                stock.purchase_price = Decimal(str(data.get('purchase_price')))
                if data.get('purchase_date'):
                    stock.purchase_date = data.get('purchase_date')
                stock.save()

                # Get current market price
                current_price = get_real_time_price(stock.symbol)

                # Calculate P&L and returns
                quantity = Decimal(str(stock.quantity))
                purchase_price = stock.purchase_price
                current_value = quantity * Decimal(str(current_price))
                initial_value = quantity * purchase_price
                pnl = current_value - initial_value
                returns = (pnl / initial_value * 100) if initial_value else Decimal('0')

                return JsonResponse({
                    'success': True,
                    'current_price': float(current_price),
                    'pnl': float(pnl),
                    'returns': float(returns)
                })

            except (ValueError, TypeError) as e:
                return JsonResponse({
                    'success': False, 
                    'error': f'Invalid data format: {str(e)}'
                }, status=400)

        elif action == 'delete':
            stock.delete()
            return JsonResponse({'success': True})

        else:
            return JsonResponse({'success': False, 'error': 'Invalid action'}, status=400)

    except Stock.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Stock not found'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)



def ai_recommendations(request):
    if 'user_id' not in request.session:
        return JsonResponse({
            'success': False,
            'error': 'Please login to view recommendations'
        })

    try:
        stocks = Stock.objects.filter(user_id=request.session['user_id'])
        recommendations = []

        for stock in stocks:
            try:
                # Get real-time data
                ticker = yf.Ticker(stock.symbol)
                hist = ticker.history(period='60d')  # Get 60 days of data for better analysis
                
                if hist.empty:
                    continue

                # Calculate technical indicators
                current_price = float(hist['Close'].iloc[-1])
                purchase_price = float(stock.purchase_price)
                
                # Calculate RSI
                delta = hist['Close'].diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
                rs = gain / loss
                rsi = 100 - (100 / (1 + rs.iloc[-1]))

                # Calculate Moving Averages
                sma_20 = hist['Close'].rolling(window=20).mean().iloc[-1]
                sma_50 = hist['Close'].rolling(window=50).mean().iloc[-1]
                
                # Volume Analysis
                avg_volume = hist['Volume'].mean()
                current_volume = hist['Volume'].iloc[-1]
                volume_trend = (current_volume - avg_volume) / avg_volume * 100

                # Price Momentum
                price_change_5d = ((current_price - hist['Close'].iloc[-6]) / hist['Close'].iloc[-6]) * 100
                price_change_20d = ((current_price - hist['Close'].iloc[-21]) / hist['Close'].iloc[-21]) * 100

                # Generate Smart Recommendations
                signals = []
                confidence = 50  # Base confidence

                # RSI Analysis
                if rsi < 30:
                    signals.append("Oversold condition detected")
                    confidence += 15
                elif rsi > 70:
                    signals.append("Overbought condition detected")
                    confidence += 15

                # Moving Average Analysis
                if current_price > sma_20 and sma_20 > sma_50:
                    signals.append("Bullish trend: Price above both SMAs")
                    confidence += 10
                elif current_price < sma_20 and sma_20 < sma_50:
                    signals.append("Bearish trend: Price below both SMAs")

                # Volume Analysis
                if volume_trend > 50:
                    signals.append(f"Unusual high volume (+{volume_trend:.1f}%)")
                    confidence += 10
                elif volume_trend < -50:
                    signals.append(f"Unusual low volume ({volume_trend:.1f}%)")
                    confidence += 5

                # Determine Action
                if current_price < purchase_price * 0.95 and rsi < 30:
                    action = 'BUY'
                    reasoning = (
                        f"Stock is trading {abs(price_change_5d):.1f}% below your purchase price. "
                        f"RSI indicates oversold conditions at {rsi:.1f}. "
                        f"{'. '.join(signals)}"
                    )
                    suggested_qty = max(1, int(10000 / current_price))
                elif current_price > purchase_price * 1.15 and rsi > 70:
                    action = 'SELL'
                    reasoning = (
                        f"Stock is trading {price_change_5d:.1f}% above your purchase price. "
                        f"RSI indicates overbought conditions at {rsi:.1f}. "
                        f"{'. '.join(signals)}"
                    )
                    suggested_qty = stock.quantity
                else:
                    action = 'HOLD'
                    reasoning = (
                        f"Current market conditions suggest holding. "
                        f"RSI: {rsi:.1f}. "
                        f"{'. '.join(signals)}"
                    )
                    suggested_qty = 0

                # Add market sentiment
                sentiment = "Bullish" if price_change_20d > 0 else "Bearish"
                strength = "Strong" if abs(price_change_20d) > 10 else "Moderate"

                recommendations.append({
                    'symbol': stock.symbol,
                    'action': action,
                    'current_price': round(current_price, 2),
                    'price_change_5d': round(price_change_5d, 2),
                    'price_change_20d': round(price_change_20d, 2),
                    'suggested_quantity': suggested_qty,
                    'confidence': min(95, round(confidence)),  # Cap confidence at 95%
                    'reasoning': reasoning,
                    'technical_indicators': {
                        'rsi': round(rsi, 1),
                        'sma_20': round(sma_20, 2),
                        'sma_50': round(sma_50, 2),
                        'volume_trend': round(volume_trend, 1)
                    },
                    'market_sentiment': {
                        'direction': sentiment,
                        'strength': strength
                    }
                })

            except Exception as e:
                print(f"Error processing stock {stock.symbol}: {str(e)}")
                continue

        if not recommendations:
            return JsonResponse({
                'success': False,
                'error': 'No recommendations available. Add stocks to your portfolio.'
            })

        return JsonResponse({
            'success': True,
            'recommendations': recommendations,
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    except Exception as e:
        print(f"Error in AI recommendations: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': 'Unable to generate recommendations at this time.'
        })

def calculate_sector_distribution(stocks):
    # Enhanced sector mapping
    sector_mapping = {
        'AAPL': 'Technology',
        'MSFT': 'Technology',
        'GOOGL': 'Technology',
        'AMZN': 'E-Commerce',
        'TSLA': 'Automotive',
        'JPM': 'Banking',
        'BAC': 'Banking',
        'WMT': 'Retail',
        'JNJ': 'Healthcare',
        'PFE': 'Healthcare',
        'XOM': 'Energy',
        'CVX': 'Energy',
        'NFLX': 'Entertainment',
        'DIS': 'Entertainment',
        'NIFT': 'Technology',
        'IBM': 'Technology',
        'WFC': 'Banking',
        'AA': 'Manufacturing'
    }
    
    sectors = {}
    total_value = 0
    
    try:
        for stock in stocks:
            current_price = float(yf.Ticker(stock.symbol).history(period='1d')['Close'].iloc[-1])
            value = current_price * stock.quantity
            sector = sector_mapping.get(stock.symbol, 'Others')
            sectors[sector] = sectors.get(sector, 0) + value
            total_value += value
        
        # Calculate percentages and sort by value
        sector_distribution = {
            sector: round((value / total_value) * 100, 1)
            for sector, value in sectors.items()
        }
        
        # Sort sectors by percentage
        sorted_sectors = dict(sorted(sector_distribution.items(), 
                                   key=lambda x: x[1], 
                                   reverse=True))
        
        return {
            'distribution': sorted_sectors,
            'total_value': round(total_value, 2)
        }
    except Exception as e:
        print(f"Error calculating sector distribution: {str(e)}")
        return {
            'distribution': {},
            'total_value': 0
        }

@csrf_exempt
def portfolio_analysis(request):
    if 'user_id' not in request.session:
        return JsonResponse({
            'success': False,
            'error': 'Please login to view portfolio analysis'
        })

    try:
        stocks = Stock.objects.filter(user_id=request.session['user_id'])
        
        if not stocks.exists():
            return JsonResponse({
                'success': False,
                'error': 'No stocks found in your portfolio'
            })

        # Initialize empty lists for sector data and recommendations
        sector_data = {'distribution': {}, 'total_value': 0}
        recommendations = []
        total_portfolio_value = 0

        # Process each stock
        for stock in stocks:
            try:
                # Get current stock data
                ticker = yf.Ticker(stock.symbol)
                current_data = ticker.history(period='1d')
                
                if not current_data.empty:
                    current_price = float(current_data['Close'].iloc[-1])
                    stock_value = current_price * stock.quantity
                    total_portfolio_value += stock_value

                    # Update sector distribution
                    sector = get_stock_sector(stock.symbol)
                    if sector in sector_data['distribution']:
                        sector_data['distribution'][sector] += stock_value
                    else:
                        sector_data['distribution'][sector] = stock_value

                    # Generate recommendation
                    hist_data = ticker.history(period='30d')
                    if not hist_data.empty:
                        recommendation = generate_stock_recommendation(
                            stock.symbol,
                            current_price,
                            float(stock.purchase_price),
                            hist_data,
                            stock.quantity
                        )
                        recommendations.append(recommendation)

            except Exception as e:
                print(f"Error processing stock {stock.symbol}: {str(e)}")
                continue

        # Calculate sector percentages
        if total_portfolio_value > 0:
            sector_data['distribution'] = {
                sector: round((value / total_portfolio_value) * 100, 1)
                for sector, value in sector_data['distribution'].items()
            }
        sector_data['total_value'] = round(total_portfolio_value, 2)

        return JsonResponse({
            'success': True,
            'sector_distribution': sector_data,
            'recommendations': recommendations,
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    except Exception as e:
        print(f"Portfolio analysis error: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': 'Unable to analyze portfolio at this time'
        })

def get_stock_sector(symbol):
    # Enhanced sector mapping
    sector_mapping = {
        'AAPL': 'Technology',
        'MSFT': 'Technology',
        'GOOGL': 'Technology',
        'AMZN': 'E-Commerce',
        'TSLA': 'Automotive',
        'JPM': 'Banking',
        'BAC': 'Banking',
        'WMT': 'Retail',
        'JNJ': 'Healthcare',
        'PFE': 'Healthcare',
        'XOM': 'Energy',
        'CVX': 'Energy',
        'NFLX': 'Entertainment',
        'DIS': 'Entertainment',
        'NIFT': 'Technology',
        'IBM': 'Technology',
        'WFC': 'Banking',
        'AA': 'Manufacturing'
    }
    return sector_mapping.get(symbol, 'Others')

def generate_stock_recommendation(symbol, current_price, purchase_price, historical_data, quantity):
    try:
        # Calculate basic metrics
        price_change = ((current_price - purchase_price) / purchase_price) * 100
        
        # Calculate RSI
        delta = historical_data['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs.iloc[-1]))

        # Calculate moving averages
        sma_20 = historical_data['Close'].rolling(window=20).mean().iloc[-1]
        sma_50 = historical_data['Close'].rolling(window=50).mean().iloc[-1]

        # Volume analysis
        avg_volume = historical_data['Volume'].mean()
        current_volume = historical_data['Volume'].iloc[-1]
        volume_change = ((current_volume - avg_volume) / avg_volume) * 100

        # Generate recommendation
        confidence = 50
        signals = []

        # Price trend analysis
        if current_price > sma_20 > sma_50:
            signals.append("Upward trend detected")
            confidence += 10
        elif current_price < sma_20 < sma_50:
            signals.append("Downward trend detected")
            confidence += 10

        # RSI analysis
        if rsi < 30:
            signals.append("Stock is oversold")
            confidence += 15
        elif rsi > 70:
            signals.append("Stock is overbought")
            confidence += 15

        # Volume analysis
        if abs(volume_change) > 50:
            signals.append(f"Unusual volume activity ({volume_change:+.1f}%)")
            confidence += 10

        # Determine action
        if price_change < -5 and rsi < 30:
            action = 'BUY'
            suggested_qty = max(1, int(10000 / current_price))
        elif price_change > 15 and rsi > 70:
            action = 'SELL'
            suggested_qty = quantity
        else:
            action = 'HOLD'
            suggested_qty = 0

        reasoning = f"{'. '.join(signals)}. "
        if action == 'BUY':
            reasoning += f"Consider buying {suggested_qty} shares at current price."
        elif action == 'SELL':
            reasoning += f"Consider taking profits on {suggested_qty} shares."
        else:
            reasoning += "Monitor for better entry/exit points."

        return {
            'symbol': symbol,
            'action': action,
            'current_price': round(current_price, 2),
            'price_change': round(price_change, 2),
            'suggested_quantity': suggested_qty,
            'confidence': min(95, confidence),
            'reasoning': reasoning,
            'metrics': {
                'rsi': round(rsi, 1),
                'sma20': round(sma_20, 2),
                'sma50': round(sma_50, 2),
                'volume_change': round(volume_change, 1)
            }
        }

    except Exception as e:
        print(f"Error generating recommendation for {symbol}: {str(e)}")
        return None

        


@csrf_exempt

def ai_assistant_response(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'})

    try:
        data = json.loads(request.body)
        user_message = data.get('message', '').lower().strip()
        user_id = request.session.get('user_id')

        if not user_id:
            return JsonResponse({
                'response': "Please login to use the AI assistant.",
                'timestamp': datetime.now().strftime('%H:%M')
            })

        # Get user's portfolio data
        stocks = Stock.objects.filter(user_id=user_id)

        # Define conversation intents
        INTENTS = {
            'portfolio_overview': ['portfolio', 'overview', 'summary', 'holdings'],
            'performance': ['performance', 'returns', 'profit', 'loss'],
            'market_analysis': ['market', 'analysis', 'trends', 'forecast'],
            'recommendations': ['recommend', 'suggest', 'advice', 'tips'],
            'risk_analysis': ['risk', 'volatility', 'exposure', 'danger'],
            'help': ['help', 'guide', 'tutorial', 'assistance']
        }

        # Determine user intent
        detected_intent = None
        for intent, keywords in INTENTS.items():
            if any(keyword in user_message for keyword in keywords):
                detected_intent = intent
                break

        # Generate response based on intent
        if detected_intent == 'portfolio_overview':
            if not stocks.exists():
                response = "Your portfolio is currently empty. Consider adding stocks to track your investments."
            else:
                total_value = sum(stock.current_price * stock.quantity for stock in stocks)
                top_holding = max(stocks, key=lambda s: s.current_price * s.quantity).symbol
                response = (
                    f"Your portfolio overview:\n"
                    f"- **Total Portfolio Value**: ${total_value:,.2f}\n"
                    f"- **Number of Holdings**: {stocks.count()}\n"
                    f"- **Top Holding**: {top_holding}\n\n"
                    "Would you like insights on a specific stock?"
                )

        elif detected_intent == 'performance':
            if not stocks.exists():
                response = "You have no stocks in your portfolio to analyze performance."
            else:
                best_stock = max(stocks, key=lambda stock: stock.return_percentage)
                worst_stock = min(stocks, key=lambda stock: stock.return_percentage)
                response = (
                    f"Here's your portfolio performance:\n"
                    f"- **Best Performing Stock**: {best_stock.symbol} ({best_stock.return_percentage:.2f}%)\n"
                    f"- **Worst Performing Stock**: {worst_stock.symbol} ({worst_stock.return_percentage:.2f}%)\n\n"
                    "Would you like advice on improving your portfolio performance?"
                )

        elif detected_intent == 'market_analysis':
            market_trend = "bullish"  # Simulated value; integrate with real-time data if available.
            top_sector = "Technology"
            response = (
                f"Current market analysis:\n"
                f"- **Market Trend**: {market_trend.capitalize()}\n"
                f"- **Leading Sector**: {top_sector}\n"
                f"- **Recent Market Movement**: The market has seen an upward trend in tech stocks, "
                "driven by strong earnings reports.\n\n"
                "Would you like sector-specific insights?"
            )

        elif detected_intent == 'recommendations':
            recommended_stocks = [
                {'symbol': 'AAPL', 'reason': 'Strong earnings and growth potential'},
                {'symbol': 'GOOGL', 'reason': 'Consistent innovation and market presence'},
                {'symbol': 'TSLA', 'reason': 'Leadership in EV and sustainability'}
            ]
            response = "Based on your portfolio and market trends, here are some stock recommendations:\n"
            for stock in recommended_stocks:
                response += f"- **{stock['symbol']}**: {stock['reason']}\n"
            response += "\nWould you like sector-based or risk-adjusted recommendations?"

        elif detected_intent == 'risk_analysis':
            if not stocks.exists():
                response = "You don’t have any stocks in your portfolio to analyze risk exposure."
            else:
                highest_volatility_stock = max(stocks, key=lambda stock: stock.volatility)
                response = (
                    f"Here's your portfolio risk analysis:\n"
                    f"- **Stock with Highest Volatility**: {highest_volatility_stock.symbol} (Volatility: {highest_volatility_stock.volatility:.2f})\n"
                    f"- **Diversification Status**: {('Well Diversified' if len(set(stock.sector for stock in stocks)) > 3 else 'Needs Improvement')}\n"
                    f"- **Risk Level**: {'High' if any(stock.volatility > 0.5 for stock in stocks) else 'Moderate to Low'}\n\n"
                    "Would you like strategies to reduce risk?"
                )

        else:
            response = (
                "I'm here to assist with your investment queries. You can ask me about:\n"
                "- **Portfolio overview**\n"
                "- **Performance analysis**\n"
                "- **Market trends**\n"
                "- **Stock recommendations**\n"
                "- **Risk management**\n"
                "- **Diversification strategies**\n\n"
                "How can I assist you today?"
            )

        return JsonResponse({
            'response': response,
            'timestamp': datetime.now().strftime('%H:%M')
        })

    except Exception as e:
        print(f"AI Assistant Error: {str(e)}")
        return JsonResponse({
            'response': "I apologize, but I encountered an error. Please try again.",
            'timestamp': datetime.now().strftime('%H:%M')
        })

def generate_portfolio_overview(stocks):
    try:
        if not stocks:
            return "Your portfolio is empty. Would you like recommendations for starting your investment journey?"
        
        total_value = sum(stock.current_value for stock in stocks)
        total_investment = sum(stock.purchase_price * stock.quantity for stock in stocks)
        overall_return = ((total_value - total_investment) / total_investment * 100) if total_investment > 0 else 0
        
        return f"""📊 Portfolio Overview:
• Total Value: ₹{total_value:,.2f}
• Total Investment: ₹{total_investment:,.2f}
• Overall Return: {overall_return:.2f}%
• Number of Stocks: {stocks.count()}

Would you like to see detailed analysis of any specific stock?"""
    except Exception:
        return "I'm having trouble analyzing your portfolio. Please try again later."

def generate_performance_analysis(stocks):
    try:
        if not stocks:
            return "Add some stocks to your portfolio to see performance analysis."
        
        best_stock = max(stocks, key=lambda x: x.get_return_percentage())
        worst_stock = min(stocks, key=lambda x: x.get_return_percentage())
        
        return f"""📈 Performance Analysis:
• Best Performer: {best_stock.symbol} ({best_stock.get_return_percentage():.2f}%)
• Worst Performer: {worst_stock.symbol} ({worst_stock.get_return_percentage():.2f}%)

Would you like specific recommendations for any of these stocks?"""
    except Exception:
        return "Unable to analyze performance at the moment. Please try again."

def generate_market_analysis():
    return """🌎 Current Market Outlook:
• Markets showing mixed trends
• Watch for upcoming earnings reports
• Keep an eye on global economic indicators
• Consider diversifying across sectors

Would you like specific market insights for any sector?"""

def generate_stock_recommendations(stocks):
    try:
        if not stocks:
            return "Let me help you start building your portfolio. What sectors interest you?"
        
        return """💡 Investment Recommendations:
• Consider diversifying across sectors
• Watch for upcoming dividend announcements
• Monitor market trends for entry points
• Set stop-loss orders to manage risk

Would you like specific recommendations for your portfolio?"""
    except Exception:
        return "I'm having trouble generating recommendations. Please try again."

def generate_risk_analysis(stocks):
    try:
        if not stocks:
            return "Add stocks to your portfolio for a detailed risk analysis."
        
        return """⚠️ Risk Analysis:
• Maintain diversification
• Monitor sector exposure
• Set stop-loss orders
• Regular portfolio rebalancing

Would you like detailed risk metrics for your portfolio?"""
    except Exception:
        return "Unable to analyze risks at the moment. Please try again."

def get_default_response():
    return """I'm here to help! You can ask me about:
• Portfolio Overview
• Performance Analysis
• Market Trends
• Stock Recommendations
• Risk Analysis

What would you like to know?"""

def generate_investment_advice(message, stocks):
    # Extract portfolio data
    portfolio_data = get_portfolio_data(stocks)
    
    # Greeting patterns
    if any(word in message for word in ['hello', 'hi', 'hey', 'greetings']):
        return f"Hello! I'm your investment assistant. I can help you analyze your portfolio, provide market insights, and offer personalized investment advice. How can I assist you today?"
    
    # Portfolio overview
    if any(phrase in message for phrase in ['portfolio overview', 'portfolio summary', 'my portfolio']):
        return generate_portfolio_overview(portfolio_data)
    
    # Best/worst performers
    if 'best' in message and ('stock' in message or 'performer' in message):
        return generate_best_performer_insight(portfolio_data)
    
    if 'worst' in message and ('stock' in message or 'performer' in message):
        return generate_worst_performer_insight(portfolio_data)
    
    # Diversification advice
    if any(word in message for word in ['diversify', 'diversification', 'allocation']):
        return generate_diversification_advice(portfolio_data)
    
    # Market trends
    if any(phrase in message for phrase in ['market trend', 'market outlook', 'market analysis']):
        return generate_market_trend_analysis()
    
    # Stock-specific advice
    for stock in portfolio_data['stocks']:
        if stock['symbol'].lower() in message:
            return generate_stock_specific_advice(stock)
    
    # Investment strategies
    if any(word in message for word in ['strategy', 'strategies', 'approach']):
        return generate_investment_strategy_advice()
    
    # Risk management
    if any(phrase in message for phrase in ['risk', 'volatility', 'downside']):
        return generate_risk_management_advice(portfolio_data)
    
    # Dividend advice
    if any(word in message for word in ['dividend', 'income', 'yield']):
        return generate_dividend_advice(portfolio_data)
    
    # Tax optimization
    if any(word in message for word in ['tax', 'taxes', 'taxation']):
        return "Consider tax-efficient investing strategies such as tax-loss harvesting, holding investments for over a year to qualify for long-term capital gains rates, and utilizing tax-advantaged accounts. Would you like more specific tax optimization advice for your portfolio?"
    
    # Help message
    if any(word in message for word in ['help', 'assist', 'what can you do']):
        return "I can help you with:\n\n• Portfolio analysis and overview\n• Stock-specific insights\n• Market trends and outlook\n• Investment strategies\n• Diversification recommendations\n• Risk management\n• Dividend optimization\n• Tax efficiency\n\nJust ask me about any of these topics!"
    
    # Default response with suggestions
    return "I'm here to help with your investment decisions. You can ask me about:\n\n• Your portfolio overview\n• Best/worst performing stocks\n• Diversification recommendations\n• Market trends\n• Specific stocks in your portfolio\n• Investment strategies\n• Risk management\n• Dividend optimization"

def get_portfolio_data(stocks):
    portfolio_data = {
        'total_value': 0,
        'total_investment': 0,
        'stocks': [],
        'sectors': {},
        'best_performer': {'symbol': None, 'return': -100},
        'worst_performer': {'symbol': None, 'return': 100}
    }
    
    for stock in stocks:
        try:
            ticker = yf.Ticker(stock.symbol)
            current_data = ticker.history(period='1d')
            
            if current_data.empty:
                continue
                
            current_price = float(current_data['Close'].iloc[-1])
            purchase_price = float(stock.purchase_price)
            quantity = stock.quantity
            
            stock_value = current_price * quantity
            investment = purchase_price * quantity
            return_pct = ((current_price - purchase_price) / purchase_price) * 100
            
            # Get additional stock info
            info = ticker.info
            sector = info.get('sector', 'Other') if hasattr(info, 'get') else 'Other'
            
            # Update sector data
            if sector in portfolio_data['sectors']:
                portfolio_data['sectors'][sector] += stock_value
            else:
                portfolio_data['sectors'][sector] = stock_value
            
            # Update best/worst performers
            if return_pct > portfolio_data['best_performer']['return']:
                portfolio_data['best_performer'] = {'symbol': stock.symbol, 'return': return_pct}
            
            if return_pct < portfolio_data['worst_performer']['return']:
                portfolio_data['worst_performer'] = {'symbol': stock.symbol, 'return': return_pct}
            
            # Add stock data
            portfolio_data['stocks'].append({
                'symbol': stock.symbol,
                'current_price': current_price,
                'purchase_price': purchase_price,
                'quantity': quantity,
                'value': stock_value,
                'return_pct': return_pct,
                'sector': sector
            })
            
            # Update totals
            portfolio_data['total_value'] += stock_value
            portfolio_data['total_investment'] += investment
            
        except Exception as e:
            print(f"Error processing {stock.symbol}: {str(e)}")
            continue
    
    # Calculate overall return
    if portfolio_data['total_investment'] > 0:
        portfolio_data['overall_return'] = ((portfolio_data['total_value'] - portfolio_data['total_investment']) / portfolio_data['total_investment']) * 100
    else:
        portfolio_data['overall_return'] = 0
    
    # Calculate sector percentages
    if portfolio_data['total_value'] > 0:
        portfolio_data['sector_allocation'] = {
            sector: (value / portfolio_data['total_value']) * 100
            for sector, value in portfolio_data['sectors'].items()
        }
    
    return portfolio_data

def generate_portfolio_overview(portfolio_data):
    if not portfolio_data['stocks']:
        return "Your portfolio is currently empty. Would you like some recommendations on stocks to consider?"
    
    overall_return = portfolio_data['overall_return']
    return_status = "positive" if overall_return >= 0 else "negative"
    
    response = f"📊 **Portfolio Overview**\n\n"
    response += f"Total Value: ₹{portfolio_data['total_value']:,.2f}\n"
    response += f"Total Investment: ₹{portfolio_data['total_investment']:,.2f}\n"
    response += f"Overall Return: {overall_return:.2f}% ({return_status})\n\n"
    
    response += "**Top Holdings:**\n"
    sorted_stocks = sorted(portfolio_data['stocks'], key=lambda x: x['value'], reverse=True)
    for i, stock in enumerate(sorted_stocks[:3], 1):
        response += f"{i}. {stock['symbol']}: ₹{stock['value']:,.2f} ({stock['return_pct']:.2f}%)\n"
    
    response += "\n**Sector Allocation:**\n"
    for sector, percentage in portfolio_data['sector_allocation'].items():
        response += f"• {sector}: {percentage:.1f}%\n"
    
    response += "\nWould you like more detailed analysis on a specific aspect of your portfolio?"
    return response

def generate_best_performer_insight(portfolio_data):
    if not portfolio_data['stocks']:
        return "Your portfolio is currently empty. Would you like some recommendations on stocks to consider?"
    
    best = portfolio_data['best_performer']
    
    if best['symbol'] is None:
        return "I couldn't determine your best performing stock. This might be due to limited historical data."
    
    # Find the stock details
    stock_details = next((s for s in portfolio_data['stocks'] if s['symbol'] == best['symbol']), None)
    
    if not stock_details:
        return f"Your best performing stock is {best['symbol']} with a return of {best['return']:.2f}%."
    
    response = f"🌟 **Best Performer: {best['symbol']}**\n\n"
    response += f"Return: {best['return']:.2f}%\n"
    response += f"Current Price: ₹{stock_details['current_price']:,.2f}\n"
    response += f"Purchase Price: ₹{stock_details['purchase_price']:,.2f}\n"
    response += f"Quantity: {stock_details['quantity']}\n"
    response += f"Total Value: ₹{stock_details['value']:,.2f}\n\n"
    
    # Add some analysis
    if best['return'] > 20:
        response += "This stock has performed exceptionally well. Consider these options:\n\n"
        response += "1. Take partial profits to lock in gains\n"
        response += "2. Set trailing stop orders to protect your profits\n"
        response += "3. Review if the stock is now overvalued based on fundamentals\n\n"
    else:
        response += "This stock is performing well. Consider:\n\n"
        response += "1. Monitoring for continued momentum\n"
        response += "2. Evaluating if the positive trend is sustainable\n"
        response += "3. Checking if there's room for additional investment\n\n"
    
    response += "Would you like a more detailed analysis of this stock?"
    return response

def generate_worst_performer_insight(portfolio_data):
    if not portfolio_data['stocks']:
        return "Your portfolio is currently empty. Would you like some recommendations on stocks to consider?"
    
    worst = portfolio_data['worst_performer']
    
    if worst['symbol'] is None:
        return "I couldn't determine your worst performing stock. This might be due to limited historical data."
    
    # Find the stock details
    stock_details = next((s for s in portfolio_data['stocks'] if s['symbol'] == worst['symbol']), None)
    
    if not stock_details:
        return f"Your worst performing stock is {worst['symbol']} with a return of {worst['return']:.2f}%."
    
    response = f"📉 **Underperformer: {worst['symbol']}**\n\n"
    response += f"Return: {worst['return']:.2f}%\n"
    response += f"Current Price: ₹{stock_details['current_price']:,.2f}\n"
    response += f"Purchase Price: ₹{stock_details['purchase_price']:,.2f}\n"
    response += f"Quantity: {stock_details['quantity']}\n"
    response += f"Total Value: ₹{stock_details['value']:,.2f}\n\n"
    
    # Add some analysis
    if worst['return'] < -20:
        response += "This stock has significantly underperformed. Consider these options:\n\n"
        response += "1. Reassess the company's fundamentals to determine if the decline is temporary or structural\n"
        response += "2. Consider averaging down if you believe in the long-term prospects\n"
        response += "3. Consider tax-loss harvesting if you decide to exit the position\n\n"
    else:
        response += "This stock is underperforming. Consider:\n\n"
        response += "1. Reviewing recent news and earnings reports\n"
        response += "2. Checking if the industry as a whole is facing challenges\n"
        response += "3. Evaluating if this is a temporary setback or a longer-term concern\n\n"
    
    response += "Would you like a more detailed analysis of this stock?"
    return response

def generate_diversification_advice(portfolio_data):
    if not portfolio_data['stocks']:
        return "Your portfolio is currently empty. Would you like some recommendations on stocks to consider for a well-diversified portfolio?"
    
    # Analyze sector allocation
    sector_allocation = portfolio_data['sector_allocation']
    
    # Check for overconcentration
    overconcentrated_sectors = [sector for sector, percentage in sector_allocation.items() if percentage > 30]
    missing_sectors = set(['Technology', 'Healthcare', 'Financial Services', 'Consumer Cyclical', 'Industrials', 'Energy']) - set(sector_allocation.keys())
    
    response = "📊 **Diversification Analysis**\n\n"
    
    if overconcentrated_sectors:
        response += "**Overconcentrated Sectors:**\n"
        for sector in overconcentrated_sectors:
            response += f"• {sector}: {sector_allocation[sector]:.1f}%\n"
        response += "\nConsider reducing exposure to these sectors to improve diversification.\n\n"
    
    if missing_sectors:
        response += "**Missing Sectors:**\n"
        for sector in missing_sectors:
            response += f"• {sector}\n"
        response += "\nConsider adding exposure to these sectors for better diversification.\n\n"
    
    # Stock count analysis
    stock_count = len(portfolio_data['stocks'])
    if stock_count < 5:
        response += "Your portfolio has only {stock_count} stocks, which may not provide adequate diversification. Consider adding more positions across different sectors.\n\n"
    elif stock_count > 20:
        response += f"Your portfolio has {stock_count} stocks. While this provides good diversification, it might be challenging to monitor effectively. Consider consolidating some positions.\n\n"
    else:
        response += f"Your portfolio has {stock_count} stocks, which is a reasonable number for balancing diversification and manageability.\n\n"
    
    # Recommendations
    response += "**Diversification Recommendations:**\n\n"
    response += "1. Aim for 8-12 stocks across 5-7 different sectors\n"
    response += "2. Limit individual positions to no more than 10% of your portfolio\n"
    response += "3. Consider adding ETFs for broader market exposure\n"
    response += "4. Include some international exposure to reduce geographic concentration\n"
    response += "5. Balance growth and value investments\n\n"
    
    response += "Would you like specific recommendations for sectors to add to your portfolio?"
    return response

def generate_market_trend_analysis():
    # This would ideally use real market data, but we'll simulate for now
    market_indices = [
        {"name": "NIFTY 50", "change": random.uniform(-1.5, 1.5)},
        {"name": "SENSEX", "change": random.uniform(-1.5, 1.5)},
        {"name": "Bank NIFTY", "change": random.uniform(-1.8, 1.8)}
    ]
    
    # Generate random sector performance
    sectors = [
        {"name": "Technology", "change": random.uniform(-2.0, 2.0)},
        {"name": "Financial Services", "change": random.uniform(-1.8, 1.8)},
        {"name": "Healthcare", "change": random.uniform(-1.5, 1.5)},
        {"name": "Consumer Goods", "change": random.uniform(-1.2, 1.2)},
        {"name": "Energy", "change": random.uniform(-2.2, 2.2)}
    ]
    
    response = "📈 **Market Trend Analysis**\n\n"
    
    response += "**Major Indices:**\n"
    for index in market_indices:
        direction = "▲" if index["change"] > 0 else "▼"
        response += f"{index['name']}: {direction} {abs(index['change']):.2f}%\n"
    
    response += "\n**Sector Performance Today:**\n"
    sectors.sort(key=lambda x: x["change"], reverse=True)
    for sector in sectors:
        direction = "▲" if sector["change"] > 0 else "▼"
        response += f"{sector['name']}: {direction} {abs(sector['change']):.2f}%\n"
    
    # Market sentiment
    avg_change = sum(index["change"] for index in market_indices) / len(market_indices)
    if avg_change > 0.5:
        sentiment = "bullish"
    elif avg_change < -0.5:
        sentiment = "bearish"
    else:
        sentiment = "neutral"
    
    response += f"\n**Market Sentiment:** {sentiment.capitalize()}\n\n"
    
    # Add some market insights
    insights = [
        "Global cues remain mixed with US markets showing volatility due to interest rate concerns.",
        "FII flows have been positive in the last week, supporting market sentiment.",
        "Upcoming earnings season will be crucial for market direction.",
        "Volatility may increase due to geopolitical tensions.",
        "Domestic institutional investors continue to provide support during market corrections."
    ]
    
    response += "**Market Insights:**\n"
    for insight in random.sample(insights, 3):
        response += f"• {insight}\n"
    
    response += "\nWould you like specific recommendations based on current market trends?"
    return response

def generate_stock_specific_advice(stock):
    symbol = stock['symbol']
    return_pct = stock['return_pct']
    
    response = f"📊 **Analysis for {symbol}**\n\n"
    response += f"Current Price: ₹{stock['current_price']:,.2f}\n"
    response += f"Your Purchase Price: ₹{stock['purchase_price']:,.2f}\n"
    response += f"Return: {return_pct:.2f}%\n"
    response += f"Quantity: {stock['quantity']}\n"
    response += f"Total Value: ₹{stock['value']:,.2f}\n\n"
    
    # Technical analysis (simulated)
    rsi_value = random.uniform(30, 70)
    ma_status = random.choice(["above 50-day MA", "below 50-day MA", "crossing 200-day MA"])
    volume_trend = random.choice(["increasing", "decreasing", "stable"])
    
    response += "**Technical Indicators:**\n"
    response += f"• RSI: {rsi_value:.1f} ({'Oversold' if rsi_value < 30 else 'Overbought' if rsi_value > 70 else 'Neutral'})\n"
    response += f"• Price is {ma_status}\n"
    response += f"• Volume trend: {volume_trend}\n\n"
    
    # Recommendation
    if return_pct > 20 and rsi_value > 65:
        action = "Consider taking partial profits"
        reasoning = "The stock has had a strong run and technical indicators suggest it may be approaching overbought territory."
    elif return_pct < -15 and rsi_value < 35:
        action = "Consider averaging down"
        reasoning = "The stock is showing signs of being oversold and may present a buying opportunity if you believe in its long-term prospects."
    elif -5 <= return_pct <= 5:
        action = "Hold and monitor"
        reasoning = "The stock is performing in line with your purchase price. Monitor upcoming news and earnings reports."
    else:
        action = "Review position"
        reasoning = "Evaluate if the current performance aligns with your investment thesis and time horizon."
    
    response += f"**Recommendation:** {action}\n"
    response += f"**Reasoning:** {reasoning}\n\n"
    
    response += "Would you like more detailed analysis or news about this stock?"
    return response

def generate_investment_strategy_advice():
    strategies = [
        {
            "name": "Value Investing",
            "description": "Focus on stocks trading below their intrinsic value",
            "suitable_for": "Patient investors with a long-term horizon",
            "key_metrics": "P/E ratio, P/B ratio, dividend yield, free cash flow"
        },
        {
            "name": "Growth Investing",
            "description": "Focus on companies with above-average growth potential",
            "suitable_for": "Investors willing to accept higher volatility for higher returns",
            "key_metrics": "Revenue growth, earnings growth, market share trends"
        },
        {
            "name": "Dividend Investing",
            "description": "Focus on stocks that pay regular dividends",
            "suitable_for": "Income-oriented investors, particularly retirees",
            "key_metrics": "Dividend yield, dividend growth rate, payout ratio"
        },
        {
            "name": "Index Investing",
            "description": "Invest in market indices through ETFs or index funds",
            "suitable_for": "Passive investors seeking market returns with low fees",
            "key_metrics": "Expense ratio, tracking error, diversification"
        }
    ]
    
    response = "📝 **Investment Strategies**\n\n"
    
    for strategy in strategies:
        response += f"**{strategy['name']}**\n"
        response += f"• Approach: {strategy['description']}\n"
        response += f"• Suitable for: {strategy['suitable_for']}\n"
        response += f"• Key metrics: {strategy['key_metrics']}\n\n"
    
    response += "**Strategy Selection Tips:**\n"
    response += "1. Consider your time horizon and risk tolerance\n"
    response += "2. Diversify across multiple strategies\n"
    response += "3. Ensure your strategy aligns with your financial goals\n"
    response += "4. Regularly review and adjust your approach\n\n"
    
    response += "Would you like me to recommend a specific strategy based on your portfolio?"
    return response

def generate_risk_management_advice(portfolio_data):
    if not portfolio_data['stocks']:
        return "Your portfolio is currently empty. Once you add stocks, I can provide risk management advice tailored to your holdings."
    
    # Calculate basic risk metrics
    stock_count = len(portfolio_data['stocks'])
    sector_count = len(portfolio_data['sector_allocation'])
    largest_position = max(portfolio_data['stocks'], key=lambda x: x['value'])
    largest_position_pct = (largest_position['value'] / portfolio_data['total_value']) * 100 if portfolio_data['total_value'] > 0 else 0
    
    response = "🛡️ **Risk Management Analysis**\n\n"
    
    # Position concentration risk
    response += "**Position Concentration:**\n"
    if largest_position_pct > 20:
        response += f"⚠️ Your largest position ({largest_position['symbol']}) represents {largest_position_pct:.1f}% of your portfolio, which creates significant concentration risk.\n\n"
    else:
        response += f"✅ Your largest position ({largest_position['symbol']}) represents {largest_position_pct:.1f}% of your portfolio, which is within reasonable limits.\n\n"
    
    # Sector concentration risk
    largest_sector = max(portfolio_data['sector_allocation'].items(), key=lambda x: x[1]) if portfolio_data['sector_allocation'] else (None, 0)
    if largest_sector[0] and largest_sector[1] > 30:
        response += f"⚠️ The {largest_sector[0]} sector represents {largest_sector[1]:.1f}% of your portfolio, indicating sector concentration risk.\n\n"
    else:
        response += f"✅ Your sector allocation is reasonably diversified, with the largest sector ({largest_sector[0]}) at {largest_sector[1]:.1f}%.\n\n"
    
    # Diversification assessment
    response += "**Diversification Assessment:**\n"
    if stock_count < 5:
        response += f"⚠️ Your portfolio has only {stock_count} stocks, which may not provide adequate diversification.\n"
    else:
        response += f"✅ Your portfolio has {stock_count} stocks across {sector_count} sectors, providing good diversification.\n\n"
    
    # Risk management recommendations
    response += "\n**Risk Management Recommendations:**\n\n"
    response += "1. **Position Sizing:** Limit individual positions to 5-10% of your portfolio\n"
    response += "2. **Stop-Loss Orders:** Consider setting stop-loss orders at 15-20% below purchase price\n"
    response += "3. **Sector Limits:** Aim to keep sector exposure below 25% of your portfolio\n"
    response += "4. **Regular Rebalancing:** Rebalance your portfolio quarterly to maintain target allocations\n"
    response += "5. **Hedging:** Consider index puts or inverse ETFs during periods of high market uncertainty\n\n"
    
    response += "Would you like specific recommendations for reducing risk in your portfolio?"
    return response

def generate_dividend_advice(portfolio_data):
    if not portfolio_data['stocks']:
        return "Your portfolio is currently empty. Once you add stocks, I can provide dividend optimization advice."
    
    # Simulate dividend data
    dividend_stocks = []
    for stock in portfolio_data['stocks']:
        # Simulate dividend yield between 0-5%
        dividend_yield = random.uniform(0, 5)
        if dividend_yield > 0.5:  # Only include stocks with meaningful dividends
            dividend_stocks.append({
                'symbol': stock['symbol'],
                'yield': dividend_yield,
                'annual_income': (dividend_yield / 100) * stock['value'],
                'value': stock['value']
            })
    
    total_dividend_income = sum(stock['annual_income'] for stock in dividend_stocks)
    portfolio_yield = (total_dividend_income / portfolio_data['total_value']) * 100 if portfolio_data['total_value'] > 0 else 0
    
    response = "💰 **Dividend Analysis**\n\n"
    response += f"Estimated Annual Dividend Income: ₹{total_dividend_income:,.2f}\n"
    response += f"Portfolio Dividend Yield: {portfolio_yield:.2f}%\n\n"
    
    if dividend_stocks:
        response += "**Top Dividend Contributors:**\n"
        sorted_dividend_stocks = sorted(dividend_stocks, key=lambda x: x['annual_income'], reverse=True)
        for i, stock in enumerate(sorted_dividend_stocks[:3], 1):
            response += f"{i}. {stock['symbol']}: {stock['yield']:.2f}% yield, ₹{stock['annual_income']:,.2f} annual income\n"
    else:
        response += "Your portfolio doesn't contain significant dividend-paying stocks.\n"
    
    response += "\n**Dividend Optimization Strategies:**\n\n"
    response += "1. **Dividend Growth:** Look for companies with a history of increasing dividends\n"
    response += "2. **Payout Ratio:** Favor companies with sustainable payout ratios (40-60%)\n"
    response += "3. **Dividend Aristocrats:** Consider stocks that have increased dividends for 25+ consecutive years\n"
    response += "4. **Dividend Reinvestment:** Reinvest dividends to compound returns over time\n"
    response += "5. **Tax Efficiency:** Hold dividend stocks in tax-advantaged accounts when possible\n\n"
    
    response += "Would you like recommendations for dividend stocks to add to your portfolio?"
    return response

@csrf_exempt
def get_stock_price(request, symbol):
    try:
        # Common Indian Stocks (NSE)
        indian_stocks = {
            'RELIANCE': 'RELIANCE.NS',   # Reliance Industries
            'TCS': 'TCS.NS',             # Tata Consultancy Services
            'HDFCBANK': 'HDFCBANK.NS',   # HDFC Bank
            'INFY': 'INFY.NS',           # Infosys
            'ICICIBANK': 'ICICIBANK.NS', # ICICI Bank
            'WIPRO': 'WIPRO.NS',         # Wipro
            'ITC': 'ITC.NS',             # ITC Limited
            'SBIN': 'SBIN.NS',           # State Bank of India
            'TATAMOTORS': 'TATAMOTORS.NS', # Tata Motors
            'MARUTI': 'MARUTI.NS'        # Maruti Suzuki
        }

        # Major Indices
        indices = {
            'NIFTY': '^NSEI',      # NIFTY 50
            'SENSEX': '^BSESN',    # BSE SENSEX
            'BANKNIFTY': '^NSEBANK' # NIFTY BANK
        }

        # International Stocks (without .NS suffix)
        international_stocks = {
            'AAPL': 'AAPL',    # Apple Inc.
            'MSFT': 'MSFT',    # Microsoft
            'GOOGL': 'GOOGL',  # Alphabet (Google)
            'AMZN': 'AMZN',    # Amazon
            'META': 'META',    # Meta (Facebook)
            'TSLA': 'TSLA',    # Tesla
            'NVDA': 'NVDA',    # NVIDIA
            'JPM': 'JPM',      # JPMorgan Chase
            'V': 'V',          # Visa
            'WMT': 'WMT'       # Walmart
        }

        # Combine all mappings
        symbol_mapping = {**indian_stocks, **indices, **international_stocks}
        
        # Get the correct symbol
        ticker_symbol = symbol_mapping.get(symbol.upper())
        if not ticker_symbol:
            raise Exception(f"Invalid stock symbol: {symbol}")

        # Fetch the stock data
        ticker = yf.Ticker(ticker_symbol)
        hist = ticker.history(period='1d')
        
        if hist.empty:
            # Try BSE if NSE fails
            if '.NS' in ticker_symbol:
                ticker_symbol = ticker_symbol.replace('.NS', '.BO')
                ticker = yf.Ticker(ticker_symbol)
                hist = ticker.history(period='1d')
                
                if hist.empty:
                    raise Exception(f"No price data found for {symbol}")

        current_price = float(hist['Close'].iloc[-1])
        
        return JsonResponse({
            'success': True,
            'price': current_price,
            'symbol': symbol,
            'exchange': 'BSE' if '.BO' in ticker_symbol else 'NSE',
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    except Exception as e:
        logger.error(f"Error fetching price for {symbol}: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f"Unable to fetch price for {symbol}. Please verify the stock symbol.",
            'details': str(e)
        }, status=404)

from django.views.decorators.http import require_http_methods

@require_http_methods(["POST"])
def edit_stock(request, stock_id):
    try:
        stock = Stock.objects.get(id=stock_id)
        data = json.loads(request.body)
        
        stock.quantity = data.get('quantity', stock.quantity)
        stock.purchase_price = data.get('price', stock.purchase_price)
        stock.purchase_date = data.get('date', stock.purchase_date)
        stock.save()
        
        return JsonResponse({'status': 'success'})
    except Stock.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Stock not found'}, status=404)
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

@require_http_methods(["POST"])
def delete_stock(request, stock_id):
    try:
        stock = Stock.objects.get(id=stock_id)
        stock.delete()
        return JsonResponse({'status': 'success'})
    except Stock.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Stock not found'}, status=404)
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

@require_http_methods(["POST"])
def update_stock(request):
    try:
        data = json.loads(request.body)
        stock_id = data.get('stock_id')
        quantity = data.get('quantity')
        purchase_price = data.get('purchase_price')
        purchase_date = data.get('purchase_date')
        
        # Get the stock object
        stock = Stock.objects.get(id=stock_id)
        
        # Update the stock
        stock.quantity = quantity
        stock.purchase_price = purchase_price
        stock.purchase_date = purchase_date
        stock.save()
        
        # Calculate new values
        current_value = float(quantity) * float(stock.current_price)
        pnl = current_value - (float(quantity) * float(purchase_price))
        returns = (pnl / (float(quantity) * float(purchase_price))) * 100
        
        return JsonResponse({
            'success': True,
            'quantity': quantity,
            'purchase_price': purchase_price,
            'current_value': current_value,
            'pnl': pnl,
            'returns': returns
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
import json

@require_http_methods(["POST"])
def ai_assistant_response(request):
    try:
        data = json.loads(request.body)
        user_message = data.get('message', '').lower()
        
        # Portfolio analysis response
        if 'portfolio' in user_message and 'analysis' in user_message:
            return JsonResponse({
                'success': True,
                'response': """Portfolio Analysis:
• Total Value: ₹15,45,678
• Today's Performance: +2.3%
• Top Sector: IT (35%)
• Risk Level: Medium
• Diversification Score: 75%

Key Observations:
1. Portfolio is tech-heavy
2. Good dividend yield at 3.2%
3. Beta is slightly high at 1.2

Would you like specific details about any aspect?"""
            })
            
        # Worst performing stocks
        elif 'worst' in user_message and 'perform' in user_message:
            return JsonResponse({
                'success': True,
                'response': """Your Worst Performing Stocks:
• YES BANK: -8.5%
• ZOMATO: -5.2%
• PAYTM: -4.1%

Recommendation:
Consider reviewing these positions and their future prospects."""
            })
            
        # Risk assessment
        elif 'risk' in user_message and 'assess' in user_message:
            return JsonResponse({
                'success': True,
                'response': """Risk Assessment:
• Overall Risk Score: Medium
• Portfolio Beta: 1.2
• Sharpe Ratio: 1.8
• Alpha: 3.5%

Key Risk Factors:
1. High sector concentration (IT: 35%)
2. Two stocks >15% of portfolio
3. Volatility above market average

Risk Management Suggestions:
1. Consider sector rebalancing
2. Set stop-loss orders
3. Add defensive stocks"""
            })
            
        # Performance tracking
        elif 'performance' in user_message and 'track' in user_message:
            return JsonResponse({
                'success': True,
                'response': """Performance Tracking:
• 1 Month: +3.2%
• 3 Months: +8.7%
• 6 Months: +12.5%
• 1 Year: +15.8%

Compared to NIFTY 50:
• Outperformance: +3.2%
• Alpha Generated: 2.1%
• Tracking Error: 1.8%

Would you like detailed performance metrics?"""
            })
            
        # Best performing stocks (existing code)
        elif 'best' in user_message and 'perform' in user_message:
            return JsonResponse({
                'success': True,
                'response': """Your Top Performing Stocks:
• INFY: +15.2%
• TCS: +12.8%
• HDFC: +10.5%

Would you like detailed analysis of any of these stocks?"""
            })
            
        # Market trends (existing code)
        elif 'market' in user_message and 'trend' in user_message:
            return JsonResponse({
                'success': True,
                'response': """Current Market Trends:
• NIFTY 50: +0.8%
• SENSEX: +0.6%
• Bank NIFTY: +1.2%

Key Sectors:
• IT: Strong momentum
• Banking: Consolidating
• Pharma: Showing recovery

Would you like specific sector analysis?"""
            })
            
        # Investment strategies (existing code)
        elif any(word in user_message for word in ['investment', 'strateg', 'recommend']):
            return JsonResponse({
                'success': True,
                'response': """Investment Recommendations:
1. Diversification across sectors
2. Regular rebalancing
3. Stop-loss management
4. Dollar-cost averaging
5. Focus on quality stocks

Specific Recommendations for Your Portfolio:
• Consider adding defensive stocks
• Reduce IT sector exposure
• Look for high-dividend yield stocks

Would you like more details about any strategy?"""
            })
            
        # Default response
        else:
            return JsonResponse({
                'success': True,
                'response': """I can help you with:
1. Portfolio Analysis
2. Investment Recommendations
3. Risk Assessment
4. Market Trends
5. Performance Tracking
6. Best/Worst Performers

What would you like to know about?"""
            })
            
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

def generate_portfolio_response(data):
    return f"""Your Portfolio Summary:
• Total Value: {data['total_value']}
• Today's Change: {data['day_gain']}
• Total Investment: {data['total_investment']}
• Overall Returns: {data['overall_returns']}

Would you like to know more about any specific aspect?"""

def generate_top_performers_response(stocks):
    response = "Your Top Performing Stocks:\n"
    for stock in stocks:
        response += f"• {stock['symbol']}: {stock['returns']}\n"
    response += "\nWould you like detailed analysis of any of these stocks?"
    return response

def generate_investment_strategy_response():
    return """Here are some recommended investment strategies:
1. Diversification across sectors
2. Regular rebalancing
3. Stop-loss management
4. Dollar-cost averaging
5. Focus on quality stocks

Would you like more details about any of these strategies?"""

def generate_market_trend_response():
    return """Current Market Trends:
• NIFTY 50: +0.8%
• SENSEX: +0.6%
• Bank NIFTY: +1.2%

Key Sectors:
• IT: Strong momentum
• Banking: Consolidating
• Pharma: Showing recovery

Would you like specific sector analysis?"""